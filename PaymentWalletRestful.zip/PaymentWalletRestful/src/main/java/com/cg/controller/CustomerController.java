package com.cg.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.beans.Customer;
import com.cg.beans.Wallet;

import com.cg.service.ICustomerService;

@RestController
public class CustomerController {
	@Autowired
	 ICustomerService customerService;
	@Autowired
	Customer customer;
	
	@PostMapping(value="/create", produces = "application/json", consumes = {MediaType.APPLICATION_JSON_VALUE})
	public Customer createAccount(@RequestBody Customer customer) {
		return customerService.createAccount(customer);
		
	}
	@GetMapping(value="/showbalance/{username}")
	public Double show(@PathVariable String username) {
		return customerService.showBalance(username);
	}
	@PostMapping(value="/deposit/{amount1}")
	public void deposit(@PathVariable Wallet wallet,@PathVariable long amount1) {
		customerService.deposit(wallet, amount1);
		
	}
	@PostMapping(value = "/withdraw/{amount1}")
	public void withdraw(@PathVariable Wallet wallet,@PathVariable long amount1) {
	
		customerService.withdraw(wallet, amount1);
		}
	@PostMapping(value="/fundtransfer/{customerAccNo}/{amount1}")
	public void fundTransfer(@PathVariable Wallet wallet ,@PathVariable String customerAccNo ,@PathVariable long amount1 ) {
		customerService.fundTransfer(wallet, customerAccNo,amount1);
	}
	

}
