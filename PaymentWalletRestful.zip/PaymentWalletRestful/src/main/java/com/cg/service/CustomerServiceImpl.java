package com.cg.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.beans.Customer;
import com.cg.beans.Transaction;
import com.cg.beans.Wallet;
import com.cg.dao.CustomerRepository;
import com.cg.dao.WalletRepository;
@Service
public class CustomerServiceImpl implements ICustomerService {
@Autowired
CustomerRepository customerRepository;
@Autowired
WalletRepository WalletRepository;

@Autowired
Customer customer;
@Autowired
Wallet wallet;
@Autowired
Transaction transaction;
@Override
public boolean deposit(Wallet wallet, long amount1) {
	
	 wallet=WalletRepository.findById(wallet.getUsername()).get();
	 

	 long balance = wallet.getBalance()+amount1;
		wallet.setBalance(balance);
		WalletRepository.save(wallet);
	return true;
}
@Override
public boolean withdraw(Wallet wallet, long amount1) {
 wallet=WalletRepository.findById(wallet.getUsername()).get();
	 
	if(wallet.getBalance()>amount1) {
		

	 long balance = wallet.getBalance()-amount1;
		wallet.setBalance(balance);
		WalletRepository.save(wallet);
	return true;
	}
	else
	{
		return false;
	}
}
@Override
public Wallet getAccountdb(String username, String password) {
	
	return null;
}


@Override
public void getTransaction() {
	
	
}
@Override
public Wallet addUser(Wallet wallet) {
	Wallet wall = new Wallet(wallet.getUsername(), wallet.getPassword(), wallet.getBalance());
	return WalletRepository.save(wall);
}

@Override
public Customer createAccount(Customer customer) {
	Customer cust = new Customer(customer.getCustomerName(), customer.getCustomerPhone(),
			customer.getCustomerAddress(), customer.getCustomerAdhar());
	Wallet wallet=new Wallet();
	
	wallet.setUsername(customer.getUsername());
	wallet.setPassword(customer.getPassword());
	wallet.setBalance(customer.getBalance());
	
	return customerRepository.save(cust);
	
}
@Override
public double showBalance(String username) {
	return WalletRepository.findById(username).get().getBalance();
}
@Override
public boolean fundTransfer(Wallet wallet, String customerAccNo, long amount1) {
	 wallet=WalletRepository.findById(wallet.getUsername()).get();
	 
		if(wallet.getBalance()>amount1) {
			

		 long balance = wallet.getBalance()-amount1;
			wallet.setBalance(balance);
			WalletRepository.save(wallet);
		return true;
		}
		else
		{
			return false;
		}
}






}
