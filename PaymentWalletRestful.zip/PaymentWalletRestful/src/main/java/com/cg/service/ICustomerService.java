package com.cg.service;



import com.cg.beans.Customer;
import com.cg.beans.Wallet;

public interface ICustomerService {
	boolean deposit(Wallet wallet, long amount1);
	boolean withdraw(Wallet wallet, long amount1);
	Wallet getAccountdb(String walletId, String passkey);

	void getTransaction();
	Wallet addUser(Wallet wallet);
	Customer createAccount(Customer customer);
	public double showBalance(String username);
	boolean fundTransfer(Wallet wallet, String customerAccNo, long amount1);
	
}
