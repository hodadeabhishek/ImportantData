package com.cg.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="customertable")
public class Customer {

	   @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	   
	    private String id;
	private String customerName;
	private String customerPhone;
	private String customerAddress;
	private String customerAdhar;
	private String username;
	private String password;
	private long balance;
	

	

	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}

	public Customer() {
		super();	
	}

	public Customer(String customerName, String customerPhone, String customerAddress, String customerAdhar
			) {
		super();
		this.customerName = customerName;
		this.customerPhone = customerPhone;
		this.customerAddress = customerAddress;
		this.customerAdhar = customerAdhar;

	
	}



	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustomerAdhar() {
		return customerAdhar;
	}

	public void setCustomerAdhar(String customerAdhar) {
		this.customerAdhar = customerAdhar;
	}


	





	@Override
	public String toString() {
		return "Customer1 [customerName=" + customerName + ", customerPhone=" + customerPhone + ", customerAddress="
				+ customerAddress + ", customerAdhar=" + customerAdhar + "]";
	}

	
}
