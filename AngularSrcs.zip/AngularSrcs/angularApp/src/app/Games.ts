export class Games{
    id:number;
    name:string;
    price:number;
}