import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { iproduct } from '../product';

@Component({
  selector: 'app-buyproduct',
  templateUrl: './buyproduct.component.html',
  styleUrls: ['./buyproduct.component.css']
})
export class BuyproductComponent implements OnInit {

  constructor(private service:ProductService) { }

  list:Array<iproduct>[]=this.service.productList;
  cart:Array<iproduct>[];
  ngOnInit() {
  }

  balanceFlag=false;

  buyProduct(product){
    if(this.service.Balance>=product.price){
      
      
       this.service.buyProduct(product);
       if(this.cart.length==0){
         this.cart.push(product);
       }
       else{
         for(let c of this.cart){
         
         }
       }

    }
    else{
     this.balanceFlag=true;
    }
  }
}
