import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { iproduct } from '../product';

@Component({
  selector: 'app-getproduct',
  templateUrl: './getproduct.component.html',
  styleUrls: ['./getproduct.component.css']
})
export class GetproductComponent implements OnInit {

  constructor(private service:ProductService) { }

  list:Array<iproduct>[]=this.service.productList;

  ngOnInit() {
  }

}
