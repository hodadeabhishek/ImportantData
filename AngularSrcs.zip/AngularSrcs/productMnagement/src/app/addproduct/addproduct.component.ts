import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { iproduct } from '../product';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {

  
  constructor(private service:ProductService) { }

  product:iproduct=new iproduct();
  ngOnInit() {
  }
addProduct(data){
  this.product.id=data.id;
  this.product.name=data.name;
  this.product.price=data.price;
  this.product.quantity=data.quantity;
  this.service.addProduct(this.product);
}
}
