import { TestBed } from '@angular/core/testing';

import { ShippingdetailsService } from './shippingdetails.service';

describe('ShippingdetailsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ShippingdetailsService = TestBed.get(ShippingdetailsService);
    expect(service).toBeTruthy();
  });
});
