import { Component, OnInit } from '@angular/core';
import { Ishippingdetails } from './shippingdetails';
import { ShippingdetailsService } from '../shippingdetails.service';

@Component({
  selector: 'app-shippingdetails',
  templateUrl: './shippingdetails.component.html',
  styleUrls: ['./shippingdetails.component.css']
})
export class ShippingdetailsComponent implements OnInit {
shippingdetails:Ishippingdetails[];
userdeatail:Ishippingdetails;
mobileno:number;
name:string;
customerid:number;
isUpdate:boolean=false;
doornum:string;
street:string;
city:string;
state:string;
pincode:number;

  constructor(private service:ShippingdetailsService) { 
    
  }

  ngOnInit() {
    this.service.getshippingdetails().subscribe(data=>this.shippingdetails=data); 
      }
  getaddress(){
    let arr=this.shippingdetails.filter(p=>p.customerid==this.customerid);
    if(arr.length>0){
      this.isUpdate=true;
      arr.map(p=>this.userdeatail=p);
      this.customerid=this.userdeatail.customerid;
      this.name=this.userdeatail.name;
      this.doornum=this.userdeatail.doornum;
      this.street=this.userdeatail.street;
      this.city=this.userdeatail.city;
      this.state=this.userdeatail.state;
      this.mobileno=this.userdeatail.mobileno
      this.pincode=this.userdeatail.pincode;
      // this.service.recieve(this.userdeatail);
    }
    else{
      alert("Wrong CustomerID ")
      this.isUpdate=false;
    }
  }
}
