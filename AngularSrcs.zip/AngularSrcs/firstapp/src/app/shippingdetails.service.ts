import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http';
import { Observable } from '../../node_modules/rxjs';
import { Ishippingdetails } from './shippingdetails/shippingdetails';
@Injectable({
  providedIn: 'root'
})
export class ShippingdetailsService {
  url:string="http://localhost:8083/users";
  constructor(private http:HttpClient) { }
  getshippingdetails():Observable<Ishippingdetails[]>{
    return this.http.get<Ishippingdetails[]>(this.url);
     }
}
