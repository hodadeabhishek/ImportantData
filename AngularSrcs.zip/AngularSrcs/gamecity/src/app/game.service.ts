import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { game } from './game';


@Injectable({
  providedIn: 'root'
})
export class GameService {


  url="/assets/game.json";
  gameList:Array<game>[];
 
  userAmount:number;

  constructor(private http:HttpClient) {
    this.getGameList().subscribe(data=>this.gameList=data);
    
  
   }

   getGameList():any{
    return this.http.get<game>(this.url);
   }

   setUserDetails(data){

   
    this.userAmount=data.userAmount-100;
    console.log(` Amount ${this.userAmount}`);
  }
   played(game){
    console.log(game);
   
  
    if(this.userAmount>=game.Amount)
    
      this.userAmount=this.userAmount-game.Amount;
     else
      alert("You dont have enough balance to play this game");
      }


  
}
