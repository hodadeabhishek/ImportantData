export class game{
   
    name:string;
    price:number;
 
} 