package com.cg.dao;


import java.util.List;

import com.cg.entities.Account;
import com.cg.entities.Customer;



public interface BankDAO {
	public Customer addCustomer(Customer c) ;
	public Account addAccount(Account a) ;
	 
	public Account deposit(Account a);
	public Account withDraw(Account a);
	public void fundTransfer(Account a1,Account a2); 
	public double showBalance(Long acno);
	public List<Account> fetchAccDetails();

}
