package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.entities.Account;
import com.cg.entities.Customer;
@Repository
public class BankDAOImpl implements BankDAO {
@PersistenceContext
EntityManager entityManager;
	@Override
	public Customer addCustomer(Customer c) {
		entityManager.persist(c);
		entityManager.flush();
return c;
	}

	@Override
	public Account addAccount(Account a) {
		entityManager.persist(a);
		entityManager.flush();
return a;

	}

	@Override
	public Account deposit(Account a) {
	entityManager.merge(a);
		return a;
	}

	@Override
	public Account withDraw(Account a) {
		entityManager.merge(a);
		return a;
	}

	@Override
	public void fundTransfer(Account a1, Account a2) {
		entityManager.merge(a1);
		entityManager.merge(a2);
	}

	@Override
	public double showBalance(Long acno) {
		Account a=entityManager.find(Account.class, acno);
		double bal=a.getAcBal();
		return bal;
		
	}

	@Override
	public List<Account> fetchAccDetails() {
		
		return null;
	}

}
