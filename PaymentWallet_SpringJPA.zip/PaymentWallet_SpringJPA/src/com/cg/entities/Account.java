package com.cg.entities;



import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;




@Entity
@Table(name="ac_details")



public class Account implements Serializable {
	
	
	

	@Id
	
	long acNo;
	double acBal;
	@OneToOne(mappedBy="account")
	Customer customer;
	public Customer getCustomer() {
		return customer;
	}



	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	
    
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	


	public Account(long acNo, double acBal) {
		super();
		this.acNo = acNo;
		this.acBal = acBal;
	}



	public long getAcNo() {
		return acNo;
	}


	public void setAcNo(long acNo) {
		this.acNo = acNo;
	}


	public double getAcBal() {
		return acBal;
	}


	public void setAcBal(double acBal) {
		this.acBal = acBal;
	}



	@Override
	public String toString() {
		return "Account [acNo=" + acNo + ", acBal=" + acBal + "]";
	}




	
	
	

}

