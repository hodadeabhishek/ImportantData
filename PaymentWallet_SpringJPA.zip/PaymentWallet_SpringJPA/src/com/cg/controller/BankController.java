package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.entities.Account;
import com.cg.entities.Customer;

import com.cg.service.BankService;

@Controller
public class BankController {
	@Autowired
	private BankService bankService;
	@RequestMapping("/index")
	public String login() {
		return "login";
		
	}
	@RequestMapping("/login")
	public String signup(Model model) {
		model.addAttribute("customer",new Customer());
		return "create";
		
	}
	@RequestMapping("/signup")
	public String createacc(Model model) {
		model.addAttribute("customer",new Customer());
		return "Signup";
		
	}
	@RequestMapping("/createSuccess")
	public String signSuccess(@ModelAttribute("customer") Customer customer,Model model) {
		model.addAttribute("customer",new Customer());

		
		bankService.addCustomer(customer);
	
		return "createSuccess";
		
	}
	@RequestMapping("/create")
	public String create() {
 //model.addAttribute("customer",new Customer());

   return "create";
	}
	@RequestMapping("/createAccount")
	
	public String Customeradding(Model model) {
		model.addAttribute("customer",new Customer());
		
		return "details";
			}
	@RequestMapping(value="/create",method=RequestMethod.POST)
	public String create(@ModelAttribute("customer") Customer customer,Model model) {
		model.addAttribute("account",new Account());
		
		bankService.addCustomer(customer);
	
		
		return "account";
	}
	
	@RequestMapping(value="/addAccount",method=RequestMethod.POST)
	public String createAccount(@ModelAttribute("account") Account account,Model model) {

	int acNo1 = (int) (Math.random() * 1000000000+1000000000 );
		long acNo = (long) (acNo1);
		
		account.setAcNo(acNo);
		bankService.addAccount(account);
	
	
		return "successcreation";
	}
	@RequestMapping(value="/show")
	public String show(Model model) {
		model.addAttribute("account",new Account());
		return "showBalance";
	}
@RequestMapping(value="/showBalance",method=RequestMethod.POST)
	public String ShowBalance(@ModelAttribute("account") Account account,Model model) {
	long acno=account.getAcNo();
		double bal=bankService.showBalance(acno);
	account.setAcBal(bal);
		return "balance";
	}
	@RequestMapping(value="/deposit")
	public 	String Deposit(Model model){
		model.addAttribute("account",new Account());
		return "depo";
	}
	@RequestMapping(value="/depositing",method=RequestMethod.POST)
	public String Deposit(@ModelAttribute("account") Account account,Model model)
	{
		long acno=account.getAcNo();
		double amount=account.getAcBal();
		double bal=bankService.showBalance(acno);
		account.setAcBal(amount+bal);
		bankService.deposit(account);
		return "depositsuccess";
	}
	@RequestMapping(value="/withDraw")
	public String withDraw(Model model){
		model.addAttribute("account",new Account());
return "withdraw";
		
	}
	@RequestMapping(value="/withdrawn",method=RequestMethod.POST)
	public String withDraw(@ModelAttribute("account") Account account,Model model)
	{
		long acno=account.getAcNo();
		double amount=account.getAcBal();
		double bal=bankService.showBalance(acno);
		if(amount<=bal-500) {
		account.setAcBal(bal-amount);
		bankService.withDraw(account);
	return "withdrawSuccess";
	}
		else {
			return "withdrawFailure";
		}
	}
	@RequestMapping(value="/fundTransfer")
	public String fundTransfer(Model model) {
		model.addAttribute("account1",new Account());
		model.addAttribute("account2", new Account());
		return "fundtransfer";
	}
	@RequestMapping(value="/transfer",method=RequestMethod.POST)
	public String fundTransfer(@ModelAttribute("account1") Account account1,@ModelAttribute("account2") Account account2, Model model)
	{
		long acno1=account1.getAcNo();
	System.out.println(acno1);
		double bal1=bankService.showBalance(acno1);
		System.out.println(bal1);
		long acno2=account2.getAcNo();
		System.out.println(acno2);
		double bal2=bankService.showBalance(acno2);
		System.out.println(bal2);
		double amount=account2.getAcBal();
		System.out.println(amount);
		if(amount<=bal1-500) {
			account1.setAcBal(bal1-amount);
		
			account2.setAcBal(bal2+amount);
			bankService.fundTransfer(account1, account2);
			
		return "fundTransferSuccess";
		}
			else {
				return "fundTransferFailure";
			}
	}
}
