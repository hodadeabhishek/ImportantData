package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.BankDAO;
import com.cg.entities.Account;
import com.cg.entities.Customer;
@Service
@Transactional
public class BankServiceImpl implements BankService {
@Autowired
private BankDAO bankDAO;
	@Override
	public Customer addCustomer(Customer c) {
		return bankDAO.addCustomer(c);

	}

	@Override
	public Account addAccount(Account a) {
		return bankDAO.addAccount(a);


	}

	@Override
	public Account deposit(Account a) {
	
		return bankDAO.deposit(a);
	}

	@Override
	public Account withDraw(Account a) {
		
		return bankDAO.withDraw(a);
	}

	@Override
	public void fundTransfer(Account a1, Account a2) {
	bankDAO.fundTransfer(a1, a2);

	}

	@Override
	public double showBalance(Long acno) {
		return bankDAO.showBalance(acno);
	}

	@Override
	public List<Account> fetchAccDetails() {
		// TODO Auto-generated method stub
		return null;
	}

}
