package com.capstore.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.model.Address;

import com.capstore.service.IShipmentService;


@CrossOrigin(origins = "*")
@RestController

public class ShipmentController {

	@Autowired
	private IShipmentService shipmentService;


//	@GetMapping(value = "/shipment/all")
//	public List<Shipment> getAllShipments() {
//		return shipmentService.getAllShipments();
//	
//	}
	
	@PostMapping(value="/create", produces = "application/json", consumes = {MediaType.APPLICATION_JSON_VALUE})
	public Address createAddress(@RequestBody Address address) {
		return shipmentService.addAddress(address);
		
	}
	@GetMapping(value = "/shipment")
	public List<Address> getAllShipmentsdetail() {
		return shipmentService.getAllShipmentsdetail();
	
	}
	@GetMapping(value="/shipment/{shipmentId}")
	public Optional<Address> getaddress(@PathVariable int shipmentId) {
		return shipmentService.getaddress(shipmentId);
	}

}
