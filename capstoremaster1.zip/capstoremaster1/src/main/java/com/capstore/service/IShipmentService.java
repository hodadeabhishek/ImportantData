package com.capstore.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.capstore.model.Address;

public interface IShipmentService {

	//public List<Shipment> getAllShipments();
	public List<Address> getAllShipmentsdetail();
	public Address addAddress(Address address);
	public Optional<Address> getaddress(int shipmentId);
		

	
}
