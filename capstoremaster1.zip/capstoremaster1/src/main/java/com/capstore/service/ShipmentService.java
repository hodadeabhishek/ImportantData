package com.capstore.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.dao.IShipmentDao;
import com.capstore.model.Address;


@Service("shipmentService")
public class ShipmentService implements IShipmentService {

	@Autowired
	IShipmentDao shipmentdao;
	

//	@Override
//	public List<Shipment> getAllShipments() {
//		return shipmentdao.findAll();
//	}
	@Override
	public Address addAddress(Address address) {
		// TODO Auto-generated method stub
		return shipmentdao.save(address);
	}
	@Override
	public List<Address> getAllShipmentsdetail() {
		return shipmentdao.findAll();
	}
	@Override
	public Optional<Address> getaddress(int shipmentId) {
	
		return shipmentdao.findById(shipmentId);
	}




}
