package com.capstore.dao;



import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capstore.model.Address;


@Repository
@Transactional
public interface IShipmentDao extends JpaRepository<Address,Integer> {
	


}
