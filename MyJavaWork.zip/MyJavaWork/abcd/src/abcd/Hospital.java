package abcd;

class Doctor{
	
	protected int age;

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		age = val;
	}
	
	class surgeon extends Doctor{
		
		public surgeon(String val) {
			
			specialization=val;
		}
		
		String specialization;
	}
	
}
public class Hospital {
public static void main(String[] args) {
	
	
}
}
