package com.cg.TicketManagement.UI;

import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.TicketManagement.Bean.TicketBean;
import com.cg.TicketManagement.Bean.TicketCategory;
import com.cg.TicketManagement.Exception.TicketException;
import com.cg.TicketManagement.Service.TicketServiceImpl;
import com.cg.TicketManagement.Utility.Util;



public class MainTicket {
	public static void main(String[] args) {
		
		TicketServiceImpl ticketserv=new TicketServiceImpl();

		
		Scanner scanner = null;
		String continueChoice = "";
		

		do {

			
			System.out.println("Enter your choice");
			System.out.println("1.Raise a Ticket");
			
			System.out.println("2.Exit From The System");

			int choice = 0;
			boolean choiceFlag = false;

			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter your choice");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;
					

					switch (choice) {
					
					case 1:
					
						boolean OptionFlag=false;
						int option=0;
						String disc=null;
						int priority=0;
						String TicketCategory = null;
						do {
							System.out.println("Select Ticket Category From Below List");
							System.out.println("1.Software Installation");
							System.out.println("2.Mailbox Creation");
							System.out.println("3.Mailbox Issue");
						
							System.out.println("Enter Option");
							scanner=new Scanner(System.in);
							 option=scanner.nextInt();
								
								
								
							try 
							{
							
								if(option!=1&&option!=2&&option!=3)
								{
									System.out.println("Choose Option 1,2 or 3");
									OptionFlag=false;
								}
								
								TicketCategory=null;
								if(option==1)
								{
									TicketCategory="Software Installation";
								}
								else if(option==2)
								{
									TicketCategory="Mailbox Creation";
								}
								else if(option==3)
								{
									TicketCategory="Mailbox Issue";
								}
								
								
							
								
							} 
							catch (InputMismatchException e) 
							{
								
								 System.out.println("Enter only digits");
								 OptionFlag=false;
								 
								
							}
							OptionFlag=true;
						
						}while(!OptionFlag);
						
						boolean DiscFlag=false;
						
						do {
							Scanner sc=new Scanner(System.in);
						try {
							
								System.out.println("Enter Description Related to issue");
								scanner=new Scanner(System.in);
								 disc=scanner.nextLine();
								
								ticketserv.validateText(disc);
								
								DiscFlag=true;
								break;
								
								
							
								} 
						catch (TicketException e)
						{
							DiscFlag=false;
							System.err.println(e.getMessage());
						}
					
						}while(!DiscFlag);
						
						boolean priorityFlag=false;
						String Priority=null;
						
						do {
							try {
								
								System.out.println("Enter Priority");
								System.out.println("1.low");
								System.out.println("2.medium");
								System.out.println("3.high");
								
								scanner=new Scanner(System.in);
								 priority=scanner.nextInt();

									if(option!=1&&option!=2&&option!=3)
									{
										System.out.println("Choose Option 1,2 or 3");
										priorityFlag=false;
									}
									
									Priority=null;
									if(option==1)
									{
										Priority="low";
									}
									else if(option==2)
									{
										Priority="medium";
									}
									else if(option==3)
									{
										Priority="high";
									}
									
								 priorityFlag=true;
								 break;
								
							}
							catch (InputMismatchException e) 
							{
								System.out.println(e.getMessage());
							}
						}while(!priorityFlag);
												
						 
						int ticketNo=(int)(Math.random()*1000);
						
						String str1 = Integer.toString(ticketNo);
						
						TicketBean ticketbean=new TicketBean(str1, TicketCategory, disc, Priority, "new", "");
						
						
						boolean ticket=ticketserv.raiseTicket(ticketbean);
						
						
						Date  date=new Date();
						System.out.println("Ticket No"+ticketNo+"logged successfully at"+date);
						
						List<TicketCategory>list1=null;
						try {
							list1=ticketserv.listCategory();
						} catch (TicketException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
					break;
					case 2:
					
						System.out.println("Thank You.....!");
						System.exit(0);

					default:
						System.out.println("Enter 1 or 2");
						choiceFlag = false;
						break;
					}

				} catch (InputMismatchException e) {
					choiceFlag = false;
					System.err.println("enter only digits");
				}

			} while (!choiceFlag);

			scanner = new Scanner(System.in);
			System.out.println("do u want to continue again(yes/no)");
			continueChoice = scanner.next();
		} while (continueChoice.equalsIgnoreCase("yes"));
		scanner.close();
		
	}

	private static void listCategory() {
		// TODO Auto-generated method stub
		
	}

}
