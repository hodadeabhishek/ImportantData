package com.cg.TicketManagement.Exception;

public class TicketException extends Exception {

	public TicketException(String message) {
		
		super(message);
	}
}
