package com.cg.TicketManagement.Utility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.TicketManagement.Bean.TicketCategory;


public class Util {
	
	private static Map<String, String>ticketCategory=new HashMap<String, String>();
	TicketCategory ticketcategory=new TicketCategory();
	
	public static Map<String,String>getTicketCategoryEntries(){
		
		ticketCategory.put("tc001", "software installation");
		ticketCategory.put("tc002", "mailbox creation");
		ticketCategory.put("tc003", "mailbox issues");
		return ticketCategory;
		
	}


	
		
}
