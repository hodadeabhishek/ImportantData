package com.cg.TicketManagement.Bean;

public class TicketCategory {
	
	private String ticketCategoryId;
	private String categoryName;
	
	
	public String getTicketCategoryId() {
		return ticketCategoryId;
	}
	public void setTicketCategoryId(String ticketCategoryId) {
		this.ticketCategoryId = ticketCategoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public TicketCategory(String ticketCategoryId, String categoryName) {
	
		this.ticketCategoryId = ticketCategoryId;
		this.categoryName = categoryName;
	}
	public TicketCategory() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return ""
	
				+"ticketCategoryId=" + ticketCategoryId 
				+ "\ncategoryName=" + categoryName+"\n\n";
	}
	
	

}
