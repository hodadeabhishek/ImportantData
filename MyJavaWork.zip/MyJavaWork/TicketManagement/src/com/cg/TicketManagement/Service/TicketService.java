package com.cg.TicketManagement.Service;

import com.cg.TicketManagement.Bean.TicketBean;
import com.cg.TicketManagement.Exception.TicketException;

public interface TicketService {
	
	public boolean raiseTicket(TicketBean ticketbean) throws TicketException;

}
