package com.cg.TicketManagement.Service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.TicketManagement.Bean.TicketBean;
import com.cg.TicketManagement.Bean.TicketCategory;
import com.cg.TicketManagement.Dao.TicketDAOImpl;
import com.cg.TicketManagement.Dao.TicketDao;
import com.cg.TicketManagement.Exception.TicketException;

public class TicketServiceImpl implements TicketService {

	TicketDao ticketdao=new TicketDAOImpl();
	public void validateText(String disc)throws TicketException {
		
		String Text="[a-zA-Z]";
		if(Pattern.matches(Text, disc))
		{
			throw new TicketException("shoud not be empty please enter discription");
		}
		
	}

	public List<TicketCategory> listCategory() throws TicketException {
		
			return ticketdao.listCategory();
		
	}

	public boolean raiseTicket(TicketBean ticketbean) {
		
		
		try {
			return ticketdao.raiseTicket(ticketbean);
		} catch (TicketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
		
		
	}

}
