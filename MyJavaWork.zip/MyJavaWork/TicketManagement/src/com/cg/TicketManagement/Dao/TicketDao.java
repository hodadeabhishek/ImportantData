package com.cg.TicketManagement.Dao;

import java.util.List;

import com.cg.TicketManagement.Bean.TicketBean;
import com.cg.TicketManagement.Bean.TicketCategory;
import com.cg.TicketManagement.Exception.TicketException;

public interface TicketDao {

	List<TicketCategory> listCategory() throws TicketException;

	boolean raiseTicket(TicketBean ticketbean)throws TicketException;

}
