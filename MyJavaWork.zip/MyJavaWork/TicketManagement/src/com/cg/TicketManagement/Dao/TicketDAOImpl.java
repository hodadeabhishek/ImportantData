package com.cg.TicketManagement.Dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.TicketManagement.Bean.TicketBean;
import com.cg.TicketManagement.Bean.TicketCategory;
import com.cg.TicketManagement.Exception.TicketException;
import com.cg.TicketManagement.Utility.Util;

public class TicketDAOImpl implements TicketDao {

	
	Map<String, String>hm2=null;
	Map<String, TicketBean> hm3=new HashMap<String, TicketBean>();
	Util m1=new Util();
	@Override
	public List<TicketCategory> listCategory() throws TicketException {
		
		hm2=m1.getTicketCategoryEntries();
	
		List<TicketCategory>list=new ArrayList(hm2.values());
		
		return  list;
	}
	@Override
	public boolean raiseTicket(TicketBean ticketbean) throws TicketException {

		hm3.put(ticketbean.getTicketNo(), ticketbean);
		
		return true;
	}

}
