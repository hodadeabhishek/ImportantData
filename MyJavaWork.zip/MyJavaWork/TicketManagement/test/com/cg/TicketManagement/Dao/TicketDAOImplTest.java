package com.cg.TicketManagement.Dao;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.TicketManagement.Bean.TicketBean;
import com.cg.TicketManagement.Bean.TicketCategory;
import com.cg.TicketManagement.Exception.TicketException;

class TicketDAOImplTest {
	TicketDAOImpl ticketdao=null;
	@BeforeEach
	void setUp() throws Exception {
		
		ticketdao=new TicketDAOImpl();
	}

	@AfterEach
	void tearDown() throws Exception {
		ticketdao=null;
	}

	@Test
	void testListCategory() throws TicketException {
		
		List<TicketCategory>list=ticketdao.listCategory();
		assertNotNull(list);
	}

	@Test
	void testRaiseTicket() throws TicketException {
		
		TicketBean ticketbean1=new TicketBean();
		
		boolean put=ticketdao.raiseTicket(ticketbean1);
		assertTrue(put);
		
	}

}
