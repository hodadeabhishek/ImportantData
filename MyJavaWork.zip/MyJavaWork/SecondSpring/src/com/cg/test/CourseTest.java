package com.cg.test;



import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.spring.Course;

public class CourseTest {

	

		public static void main(String[] args) {
			
			
			
			
			ApplicationContext context=new ClassPathXmlApplicationContext();
			
			Course c=(Course) context.getBean("course");
			
			
			System.out.println(c);

	}

}