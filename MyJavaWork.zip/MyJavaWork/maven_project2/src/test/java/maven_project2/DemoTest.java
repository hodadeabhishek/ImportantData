package maven_project2;

import static org.testng.AssertJUnit.assertTrue;
import org.junit.jupiter.api.Test;

public class DemoTest {
	
	
	@Test
	public void shouldReturnTrue()
	{
		Demo d=new Demo();
		
		assertTrue(d.getBoolean());
	}


}
