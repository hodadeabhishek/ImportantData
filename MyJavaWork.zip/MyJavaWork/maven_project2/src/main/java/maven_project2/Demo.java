package maven_project2;

public class Demo 
{
	

	public Boolean getBoolean()
		{
			return true;
		}
}


