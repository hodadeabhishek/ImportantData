import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Ignore;
import org.junit.jupiter.api.Test;

public class TestClass {

public void testDisp()

{
	assertEquals(11, Integer.parseInt("11"));
}
}
