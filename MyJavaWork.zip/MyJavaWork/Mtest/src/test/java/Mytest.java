import pack.Person;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assumptions.assumeTrue;


public class Mytest {
public static void setBeforeAllTEst() {
	System.out.println(" Executes once before all test method in"+"this class");
	
}
public static void doAfterAllTest() {
	System.out.println("Executes once before all test method in\"+\"this class");
}

@BeforeEach
private void setBeforeTest() {

	System.out.println("Executes once before test method in\"+\"this class");
}
@AfterEach
private void doAfterTests() {
	
	System.out.println("Executes after each test method in\"+\"this class");
}

@Test
private void GetFullName() {

	System.out.println("from GetFullName()");
	Person per=new Person("Robert"," King");
	assertEquals("Robert King",per.getFullName());
}
@Test

	public void NullIsInName() {
		
		System.out.println("from NullIsInName()");
		Person per1=new Person("null"," King");
		assertNotNull("full name null",per1.getFullName());
		assertNotNull("First name null",per1.getFirstName());
}
	
	@Test
	void trueAssumption()
	{
		Person per3=new Person("Robert","King",5000);
		assumeTrue(per3.getSalary()>4000);
	}
	
	

}
