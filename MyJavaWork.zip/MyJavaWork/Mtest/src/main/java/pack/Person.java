package pack;
public class Person {

	private String firstName;
	private String lastName;
	private int salary;
	
	 Person()
	{
		
	}
	 public Person(String fname,String lname)
	 {
		 this.firstName=fname;
		 this.lastName=lname;
	 }
	public Person(String firstName, String lastName, int salary) {
	
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
	}
	 
	public String getFullName()
	{
		
		String first=this.firstName;
		String last=this.lastName;
		return first+""+last;
		
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	public static void main(String[] args) {
		
		Person P=new Person("a","b");
	}
	 
}
