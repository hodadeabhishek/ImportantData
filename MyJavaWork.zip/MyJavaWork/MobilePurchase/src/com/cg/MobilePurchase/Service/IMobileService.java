    
package com.cg.MobilePurchase.Service;

import com.cg.MobilePurchase.Bean.Customer;
import com.cg.MobilePurchase.Bean.Mobile;
import com.cg.MobilePurchase.Exception.MobileException;

public interface IMobileService {

	void ValidateName(String name) throws MobileException;

	void validateAddress(String address) throws MobileException;

	void validatePhone(String phone) throws MobileException;

	Mobile purchaseMobile(int mobilechoice) throws MobileException;

	void storeIntoMap(Customer cust) throws MobileException;

	Customer GenBill(int genid) throws MobileException;




}