package com.cg.MobilePurchase.Service;

import java.util.regex.Pattern;

import com.cg.MobilePurchase.Bean.Customer;
import com.cg.MobilePurchase.Bean.Mobile;
import com.cg.MobilePurchase.Dao.IMobileDao;
import com.cg.MobilePurchase.Dao.MobileDao;
import com.cg.MobilePurchase.Exception.MobileException;



public class MobileService implements IMobileService {

	IMobileDao mobiledao=new MobileDao();
	@Override
	public void ValidateName(String name) throws MobileException {
		
		String nameRegEx = "[a-zA-Z ]+";
		if (Pattern.matches(nameRegEx, name) == false) {
			throw new MobileException("name should contain only alphabets");
			}
	}

	@Override
	public void validateAddress(String address) throws MobileException {
	
		String addressRegEx = "[a-zA-Z ]+";
		if (Pattern.matches(addressRegEx, address) == false) {
			throw new MobileException("address should contain only alphabets");
		}

	}

	@Override
	public void validatePhone(String phone) throws MobileException {
		String phoneRegEx = "[7|8|9]{1}[0-9]{9}";
		if (Pattern.matches(phoneRegEx, phone) == false) {
			throw new MobileException("mobile number should contain exactly 10 digits");
		}
		
	}

	@Override
	public Mobile purchaseMobile(int mobilechoice) throws MobileException {
		
		System.out.println("service");
		 return mobiledao.purchaseMobile(mobilechoice);
	}

	@Override
	public void storeIntoMap(Customer cust) throws MobileException {
		
		mobiledao.storeIntoMap(cust);
		
	}

	@Override
	public Customer GenBill(int genid) throws MobileException {
		
		return mobiledao.GenBill(genid);
	}

	


	

}