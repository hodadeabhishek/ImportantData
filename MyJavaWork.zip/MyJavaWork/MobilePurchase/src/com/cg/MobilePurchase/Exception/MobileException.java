package com.cg.MobilePurchase.Exception;

public class MobileException extends Exception {


public MobileException(String message) {
	super(message);
	
}
}
