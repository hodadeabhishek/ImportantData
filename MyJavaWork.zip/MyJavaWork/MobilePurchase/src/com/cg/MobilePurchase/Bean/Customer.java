package com.cg.MobilePurchase.Bean;

import java.time.LocalDate;

public class Customer extends Mobile {
	
	private String custName;
	private String address;
	private String phone;
	private int custID;
	private int orderID;
	private LocalDate date;
	private double priceWithGst;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(String custName, String address, String phone, int custID, int orderID, LocalDate date) {
		super();
		this.custName = custName;
		this.address = address;
		this.phone = phone;
		this.custID = custID;
		this.orderID = orderID;
		this.date = date;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public int getCustID() {
		return custID;
	}
	public void setCustID(int custID) {
		this.custID = custID;
	}
	public int getOrderID() {
		return orderID;
	}
	public void setOrderID(int orderID) {
		this.orderID = orderID;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	
	public double getPriceWithGst() {
		return priceWithGst;
	}
	public void setPriceWithGst(double priceWithGst) {
		this.priceWithGst = priceWithGst;
	}
	@Override
	public String toString() {
		return""
				
				+"custName: " + custName 
				+ "\naddress: " + address 
				+ "\nphone: " + phone
				+ "\ngenid: " + orderID
				+ "\ndate: " + date 
				+"\n"+getMobileName()
				+ "\n Mobile Model No: " +getMobileModel()
				+ "\n Mobile Price: "+ getMobileprice()
				+"\n Mobile Price with 12% Gst:"+getPriceWithGst();
	}
	
	

}
