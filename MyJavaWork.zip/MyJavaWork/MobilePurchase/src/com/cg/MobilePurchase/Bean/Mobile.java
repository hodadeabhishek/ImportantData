package com.cg.MobilePurchase.Bean;

import java.util.Comparator;

public class Mobile {
	
	private int mobileModel;
	private	String mobileName;
	private	double mobileprice;
	
	public Mobile() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Mobile(int mobileModel, String mobileName, double mobileprice) {
		super();
		this.mobileModel = mobileModel;
		this.mobileName = mobileName;
		this.mobileprice = mobileprice;
	}
	public int getMobileModel() {
		return mobileModel;
	}
	public void setMobileModel(int mobileModel) {
		this.mobileModel = mobileModel;
	}
	public String getMobileName() {
		return mobileName;
	}
	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}
	public double getMobileprice() {
		return mobileprice;
	}
	public void setMobileprice(double mobileprice) {
		this.mobileprice = mobileprice;
	}
	
	/* public static Comparator<Mobile> StuNameComparator = new Comparator<Mobile>() {

			public int compare(Mobile s1, Mobile s2) {
			   String StudentName1 = s1.getMobileName().toUpperCase();
			   String StudentName2 = s2.getMobileName().toUpperCase();

			   //ascending order
			   return StudentName1.compareTo(StudentName2);

			   //descending order
			   //return StudentName2.compareTo(StudentName1);
		    }};*/
	
	public static Comparator<Mobile> StuNameComparator = new Comparator<Mobile>() {

		public int compare(Mobile s1, Mobile s2) 
		{
		   double StudentName1 = s1.getMobileprice();
		   double StudentName2 = s2.getMobileprice();

		   //ascending order
		   return Double.compare(StudentName1, StudentName2);

		   //descending order
		}	   //return StudentName2.compareTo(StudentName1);
	};
	@Override
	public String toString() {
		return ""
				+"\nmobileModel=" + mobileModel 
				+ "\nmobileName=" + mobileName 
				+ "\nmobileprice=" + mobileprice+"\n";
	}
	
	
		

}