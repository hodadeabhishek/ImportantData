package com.cg.MobilePurchase.UI;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

import com.cg.MobilePurchase.Bean.Customer;
import com.cg.MobilePurchase.Bean.Mobile;
import com.cg.MobilePurchase.Exception.MobileException;
import com.cg.MobilePurchase.Service.IMobileService;
import com.cg.MobilePurchase.Service.MobileService;
import com.cg.MobilePurchase.Util.Utility;





public class MainMobile {

	static IMobileService mobileserve=new MobileService();
	static Mobile mobile=new Mobile();
	
	public static void main(String[] args) {
		
		Scanner scanner = null;

	

		String continueChoice = "";

		do {

			System.out.println("****** Welcome To ABC Mobile Shop ******");
			System.out.println("1.Purchase Mobile");
			System.out.println("2.Display Bill");
			System.out.println("3.exit");
		
			

			int choice = 0;
			boolean choiceFlag = false;

			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter your choice");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;

					switch (choice) {

					case 1:

						String name = "";
						boolean nameFlag = false;

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Your name");
							try {
								name = scanner.nextLine();
								mobileserve.ValidateName(name);
							
								nameFlag = true;
								break;
							} catch (MobileException e) {
								nameFlag = false;
								System.out.println(e.getMessage());
							}
						} while (!nameFlag);

						String address = "";
						boolean addressFlag = false;
						
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter address of the customer");
							address = scanner.nextLine();
							try {
								
								mobileserve.validateAddress(address);
								addressFlag = true;
								break;
								
								} 
							catch (MobileException e) {
								addressFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!addressFlag);

						
						String phone = "";
						boolean phoneFlag = false;
						do {
							
							scanner = new Scanner(System.in);
							System.out.println("Enter Your mobile number ");
							phone = scanner.nextLine();
							
							try {
								mobileserve.validatePhone(phone);
								phoneFlag = true;
								break;

								} 
							catch (MobileException e) {
								phoneFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!phoneFlag);
						
						
						Utility util=new Utility();
						ArrayList<Mobile>hm2=util.displayMobiles();
						
						System.out.println(hm2.toString().replaceAll("[\\[\\],]",""));
				
						boolean chFlag=false;
						int mobilechoice=0;
						do {
							
							try {
								
								System.out.println("Enter Model No");
								scanner=new Scanner(System.in);
								mobilechoice=scanner.nextInt();
								System.out.println(mobilechoice);
								chFlag=true;
								break;
								 
								 } 
							catch (InputMismatchException e)
							{
								
								 chFlag=false;
								System.err.println("Enter Digit only");
							}
						
						
						 	
						}while(!chFlag);
						

						int custID=(int)(Math.random()*1000);
						int orderID=(int)(Math.random()*1000);
						
						LocalDate localDate = LocalDate.now();
						
						Customer cust=new Customer(name, address, phone, custID, orderID, localDate);
						
						
						
						try {
							Mobile mobile=mobileserve.purchaseMobile(mobilechoice);
							System.out.println("you booked.....! ");
							System.out.println(mobile);
							cust.setMobileName(mobile.getMobileName());
							cust.setMobileModel(mobile.getMobileModel());
							cust.setMobileprice(mobile.getMobileprice());
							cust.setPriceWithGst(mobile.getMobileprice()+(mobile.getMobileprice()*0.12));
						
						} catch (MobileException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					
						
						try {
							mobileserve.storeIntoMap(cust);
						} catch (MobileException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						System.out.println("Your Order Placed Successfully and Your Order Id is"+cust.getOrderID());
		

						break;
					case 2:
						System.out.println("Enter Your Order ID");
						
						scanner=new Scanner(System.in);
						
						int genid=scanner.nextInt();
						
							try {
								Customer customer=mobileserve.GenBill(genid);
								
								System.out.println(customer);
								
							} catch (MobileException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						
						

					break;
					case 3:
						System.out.println("*** Thank you *** ");
						System.exit(0);
						break;

					default:
						choiceFlag = false;
						System.out.println("input should be 1, 2 or 3");
						break;
					}

				} catch (InputMismatchException e) {
					choiceFlag = false;
					System.err.println("please enter only digits");
				}

			} while (!choiceFlag);

			scanner = new Scanner(System.in);
			System.out.println("do you want to continue again [yes/no]");
			continueChoice = scanner.nextLine();

		} while (continueChoice.equalsIgnoreCase("yes"));
		scanner.close();
	}


		
	}