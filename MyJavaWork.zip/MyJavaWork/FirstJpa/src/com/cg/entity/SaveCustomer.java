package com.cg.entity;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class SaveCustomer {
	
	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("FirstJpa");
		
		EntityManager entityManager=emf.createEntityManager();
		
		entityManager.getTransaction().begin();
		Customer customer=new Customer();
		customer.setId("501");
		customer.setAddress("Mumbai");
		customer.setName("Badoda");
		
		/*Customer customer1=new Customer();
		customer1.setId("601");
		customer1.setAddress("delhi");
		customer1.setName("Punjab");*/
		
		entityManager.persist(customer);
		
		
		entityManager.getTransaction().commit();
		
		entityManager.close();
		emf.close();
		
		
	}

}
