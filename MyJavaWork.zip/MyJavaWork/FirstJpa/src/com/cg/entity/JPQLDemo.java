package com.cg.entity;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class JPQLDemo {

	public static void main(String[] args) {
		
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("FirstJpa");
		
		EntityManager entityManager=emf.createEntityManager();
		
		Query query=entityManager.createQuery("Select UPPER(customer.name) from Customer customer ");
		
		List<String> list= query.getResultList();
		
		list.stream().forEach(System.out::println);
	
		
Query query1=entityManager.createQuery("Select LOWER(customer.name) from Customer customer ");
		
		List<String> list1= query1.getResultList();
		
		list1.stream().forEach(System.out::println);
	}
}
