package com.cg.entity;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Fetch {

	public static void main(String[] args) {
		
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("FirstJpa");
		
		EntityManager entityManager=emf.createEntityManager();
		
		entityManager.getTransaction().begin();
		Customer customer=entityManager.find(Customer.class,"501");
	
		System.out.println(customer.getId()+", "+customer.getName()+", "+customer.getAddress());
		
		entityManager.persist(customer);
		
		entityManager.getTransaction().commit();
		
		entityManager.close();
		emf.close();
		
	}
}
