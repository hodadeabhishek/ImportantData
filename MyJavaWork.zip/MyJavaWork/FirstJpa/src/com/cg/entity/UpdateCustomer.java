package com.cg.entity;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class UpdateCustomer {
	
	public static void main(String[] args) {
		
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("FirstJpa");
		
		EntityManager entityManager=emf.createEntityManager();
		
		entityManager.getTransaction().begin();
		Customer customer=entityManager.find(Customer.class,"301");
		customer.setId("301");
		customer.setAddress("Indian");
		customer.setName("Maharashtra Bank");
		
		entityManager.persist(customer);
		
		entityManager.getTransaction().commit();
		
		entityManager.close();
		emf.close();
		
	}
	

}
