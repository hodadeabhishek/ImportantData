package com.cg.PaymentWallet.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Transaction {
	   @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	   
	    private String id;
	private String date;
	private String amount;
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Transaction(String date, String amount) {
		super();
		this.date = date;
		this.amount = amount;
	}
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "FundTransaction [date=" + date + ", amount=" + amount + "]";
	}
	
	

}
