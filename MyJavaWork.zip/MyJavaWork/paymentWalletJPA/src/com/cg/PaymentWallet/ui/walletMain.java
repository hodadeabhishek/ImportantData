package com.cg.PaymentWallet.ui;

import java.util.Date;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

import com.cg.PaymentWallet.Exception.MPException;
import com.cg.PaymentWallet.dto.Customer;
import com.cg.PaymentWallet.dto.Walletjpa;
import com.cg.PaymentWallet.service.WalletService;
import com.cg.PaymentWallet.service.WalletServiceImpl;


public class walletMain {

	
public static void main(String[] args) {
		
		Scanner scanner=null;
		
		
		String continueChoice="";
		
		WalletService service=new WalletServiceImpl();
	
		
		do {
				
				System.out.println("***********************WelCome to Standered Bank E-Wallet***********************");
				System.out.println("1.Login");
				System.out.println("2.Create Your Account");
				
				int choice;
				boolean choiceFlag=false;
				do {
					
					scanner=new Scanner(System.in);
					System.out.println("Enter your choice:  ");
					
					try {
						choice=scanner.nextInt();
						choiceFlag=true;
						switch(choice) {
							
							case 1: 
								    System.out.println("*************************Log into Your Account*************************");
									String username;
									String password="";
									Walletjpa walletjpa;
									boolean logFlag=false;
									do {
										scanner=new Scanner(System.in);
										boolean login;
										Walletjpa wallet1=null;
						
										System.out.print("Enter your User Name: ");
										try {
											username=scanner.nextLine();
										
										
										System.out.print("Enter your password ");
										password=scanner.nextLine();
										wallet1=service.valideLogin(username,password);
										
										logFlag=true;
									
										
										System.out.println("Welcome "+wallet1.getUsername()+" You successfully log in");
										
										System.out.println("****************************Menu*****************************");
										System.out.println("1.Display Balance:");
										System.out.println("2.Deposit money:");
										System.out.println("3.Withdraw Money:");
										System.out.println("4.Fund Transfer");
										System.out.println("5.Print Transaction");
										System.out.println("6.Logout");
										int option;
										boolean optionFlag=false;
										do {
											scanner=new Scanner(System.in);
											System.out.println("\nChoose Option:");
											try {
												option=scanner.nextInt();
												
												switch(option) {
												
													case 1:
															System.out.println("**************************display Balance****************************\n");
															
															System.out.println("Your Total Balance: "+wallet1.getBalance()+"\n");
															break;
															
													case 2:
															System.out.println("*************************Deposit Balance***************************");
															long amount;
															long newBalance;
															boolean amountFlag=false;
															do {
																scanner=new Scanner(System.in);
																System.out.println("Enter Amount which you want to deposit");
																try {
																	
																	amount=scanner.nextLong();
																	service.validateAmount(amount);
																	long amount1=amount;
																	amount=amount+wallet1.getBalance();
																	wallet1.setBalance(amount);
																	newBalance=service.depositMoney(wallet1,amount1);
																	System.out.println(+amount1+"Rs."+ " : amount Credited in your account ");
																	System.out.println("Your Updated Wallet Balance is: "+newBalance+"Rs.");
																	amountFlag=true;
																	
																}catch(InputMismatchException e) {
																	
																	System.out.println("Amount should be positve Integer\n");
																	
																}catch(MPException e1) {
																	
																	System.err.println(e1.getMessage()+"\n");
																}
															
															
															}while(!amountFlag);
															break;
													case 3:
															System.out.println("****************************Withdraw:*****************************");
															long moneyDr;
															long newBalance1;
															boolean balanceFlag=false;
															do {
																scanner=new Scanner(System.in);
																System.out.println("Enter Amount which you want to withdraw");
																try {
																	moneyDr=scanner.nextLong();
																	service.validateMoneyDr(moneyDr);
																	if((wallet1.getBalance()- moneyDr) >=0) {
																		long amount1=moneyDr;
																		moneyDr=wallet1.getBalance()-moneyDr;
																		wallet1.setBalance(moneyDr);
																		newBalance1=service.withdrawMoney(wallet1,amount1);
																		System.out.println(+amount1+"Rs."+" : amount Debited from your account ");
																		System.out.println("Updated Wallete Balance is: "+newBalance1+"Rs");
																		balanceFlag=true;
				
																	}
																	else {
																		
																		System.err.println("You dont have suffcient Balance\n");
																		balanceFlag=true;
																		
																	}
																	
																}catch(InputMismatchException e) {
																	
																	System.err.println("please enter positive Integer\n");
																	
																}catch(MPException e1) {
																	
																	System.err.println(e1.getMessage());
																	
																}
																
															}while(!balanceFlag);
													        break;
													case 4:
															System.out.println("**************************Fund Transfer:***************************");
															
															
															String customerAccNo = "";
															boolean customerAccFlag = false;
															do {
																scanner=new Scanner(System.in);
																System.out.println("Enter the accountNo in which you want to transfer money ");
																try {

																	 customerAccNo=scanner.nextLine();
																	service.validateAccNo(customerAccNo);
																	
																	customerAccFlag = true;
																} catch (MPException e) {
																	customerAccFlag = false;
																	System.err.println("Account No should be 6 digit");
																}
															} while (!customerAccFlag);

															
															long fundAmount;
															long newBalance2;
															boolean fundFlag=false;
															do {
																
																
																
																System.out.println("Enter amount which you want to transfer:");
																try {
																	
																	
																	
																	fundAmount=scanner.nextLong();
																	service.validateFundAmount(fundAmount);
																	if((wallet1.getBalance()-fundAmount)>=0) {
																	
																		System.out.println(fundAmount+"Rs"+" sucessfully transfered to Account No:"+customerAccNo);
																		long amount1=fundAmount;
																		fundAmount=wallet1.getBalance()-fundAmount;
																		wallet1.setBalance(fundAmount);
																		newBalance2=service.fundTransfer(wallet1,amount1,customerAccNo);
																		System.out.println("Your Wallet Balance Is: "+newBalance2);
																		fundFlag=true;
																		
																	}
																	else {
																		System.err.println("You dont have sufficient Balance\n");
																		fundFlag=true;
																	}
																	
																}catch(InputMismatchException e) {
																	
																	System.err.println("amount should be positive number\n");
																}catch(MPException e1) {
																	
																	System.err.println("Amount should be positive number \n");
																}
																
																
															}while(!fundFlag);
													        break;
													case 5:
															System.out.println("******************************Mini Statement******************************");
													
															service.getTransaction();
														
															System.out.println("\nYour Wallete Balance is: "+wallet1.getBalance()+"Rs.");
													
													
															
													        break;
													case 6:
															System.out.println("You successfully log out from system");
															optionFlag=true;
											        		break;
													default:
															
															System.err.println("Please enter correct option");
															
												
												}
											
											
											}catch(InputMismatchException e) {
												optionFlag=false;
												System.err.println("Please enter only digits:");
				
											}
											
											
										}while(!optionFlag);
										
										
										}catch(InputMismatchException e) {
											logFlag=false;
											System.err.println("Id should be digit only ");
										}
										catch(MPException e) {
											logFlag=true;
											System.err.println(e.getMessage());
										}
									
									
									}while(!logFlag);
									
									break;
									
							case 2:
									
							Customer customer=new Customer();
								
								String customerName = "";
								boolean customerNameFlag = false;
								do {
									scanner = new Scanner(System.in);
									System.out.println("Enter Your Name : ");
									try {
										customerName = scanner.nextLine();
										service.validateName(customerName);
										customer.setCustomerName(customerName);
										customerNameFlag = true;
									} catch (MPException e) {
										customerNameFlag = false;
										System.err.println(e.getMessage());
									}
								} while (!customerNameFlag);

								String customerAddress = "";
								boolean customerAddressFlag = false;
								do {
									scanner = new Scanner(System.in);
									System.out.println("Enter Your Address : ");
									try {
										customerAddress = scanner.nextLine();
										service.validateAddress(customerAddress);
										customer.setCustomerAddress(customerAddress);
										customerAddressFlag = true;
									} catch (MPException e) {
										customerAddressFlag = false;
										System.err.println(e.getMessage());
									}
								} while (!customerAddressFlag);

								String password1 = "";
								boolean passwordflag = false;
								do {
									scanner = new Scanner(System.in);
									System.out.println("Enter Your Password : ");
									try {
										password1 = scanner.nextLine();
										service.validatePassword(password1);
										
										passwordflag = true;
									} catch (MPException e) {
										passwordflag = false;
										System.err.println("Password Should Contain  letters and numbers");
									}
								} while (!passwordflag);

								String customerPhone = "";
								boolean customerPhoneFlag = false;
								do {
									scanner = new Scanner(System.in);
									System.out.println("Enter Your Phone Number : ");
									try {
										customerPhone = scanner.nextLine();
										service.validatePhone(customerPhone);
										customer.setCustomerPhone(customerPhone);
										customerPhoneFlag = true;
									} catch (MPException e) {
										customerPhoneFlag = false;
										System.err.println(e.getMessage());
									}
								} while (!customerPhoneFlag);

								String customerAdhar = "";
								boolean customerAdharFlag = false;
								do {
									scanner = new Scanner(System.in);
									System.out.println("Enter Your Adhar Card Number : ");
									try {
										customerAdhar = scanner.nextLine();
										service.validateAdhar(customerAdhar);
										customer.setCustomerAdhar(customerAdhar);
										customerAdharFlag = true;
									} catch (MPException e) {
										customerAdharFlag = false;
										System.err.println("It Should be 12 digit");
									}
								} while (!customerAdharFlag);

							

							try {
								service.createAccount(customer);
							} catch (MPException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}

									
									long balance=0;
									boolean balanceFlag=false;
									do {
										System.out.println("Enter Initial amount which u want to deposit ");
										try {
											
											balance=scanner.nextLong();
											service.validateAmount(balance);
											balanceFlag=true;
										
										}catch(InputMismatchException e) {
											
											System.err.println("Amount should be positive number");
											
										}catch(MPException e) {
											
											System.err.println(e.getMessage()+"\n");
										}
										
									}while(!balanceFlag);
									
									 walletjpa=new Walletjpa(customerName,password1,balance);
									boolean flag=service.adduser(walletjpa);
									if(flag=true) {
										System.out.println("Your account successfully created With User Name: "+walletjpa.getUsername());
									}
									
									break;
									
							default:
									choiceFlag=false;
									System.out.println("Enter correct option");
		
						
						}	
					}catch(InputMismatchException e) {
						
						choiceFlag=false;
						System.err.println("Please enter digits only");
						
					}
					
				}while(!choiceFlag);
				
				
			scanner=new Scanner(System.in);
			System.out.println("do u want to continue again(yes/no)");
			continueChoice=scanner.nextLine();
			
			
		}while(continueChoice.equalsIgnoreCase("yes"));
		
		System.out.println("**Thank You! Please Visit again****");
		
		scanner.close();
		
		
		
	}
	
	
	
}
