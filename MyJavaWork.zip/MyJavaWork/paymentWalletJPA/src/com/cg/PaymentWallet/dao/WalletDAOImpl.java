package com.cg.PaymentWallet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.PaymentWallet.Exception.MPException;
import com.cg.PaymentWallet.dto.Customer;
import com.cg.PaymentWallet.dto.Transaction;
import com.cg.PaymentWallet.dto.Walletjpa;

import sun.awt.windows.WLightweightFramePeer;





public class WalletDAOImpl implements WalletDAO {
	
	
	Connection c=null;
	Statement stmt=null;
	ResultSet rs=null;
	

	

	@Override
	public long deposit(Walletjpa walletjpa, long amount1) 
	{
		

		
		EntityManagerFactory e=Persistence.createEntityManagerFactory("paymentWalletJPA");
		EntityManager e1=e.createEntityManager();
		e1.getTransaction().begin();
		
		
		Walletjpa wall =(Walletjpa)e1.createNativeQuery("select * from walletjpa where username="+"username", Walletjpa.class).getSingleResult();
		
		wall.setBalance(walletjpa.getBalance());
	
		Date date = Calendar.getInstance().getTime();  
		DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");  
		String strDate = dateFormat.format(date);  
    
    
		String amount=Long.toString(amount1);
		amount=amount+"Rs.credited to wallet";
	

		Transaction fund=new Transaction(strDate, amount);

		e1.persist(wall);
		e1.persist(fund);



		e1.close();



	
return walletjpa.getBalance();

		
	}

	@Override
	public long withdraw(Walletjpa walletjpa,long amount1) {
		
		EntityManagerFactory e=Persistence.createEntityManagerFactory("paymentWalletJPA");
		EntityManager e1=e.createEntityManager();
		e1.getTransaction().begin();
		
		Walletjpa wall =(Walletjpa)e1.createNativeQuery("select * from walletjpa where username="+"username", Walletjpa.class).getSingleResult();
		
		wall.setBalance(walletjpa.getBalance());
	
		Date date = Calendar.getInstance().getTime();  
		DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");  
		String strDate = dateFormat.format(date);  
    
    
		String amount=Long.toString(amount1);
		amount=amount+"Rs.debited from wallet";
	

		Transaction fund=new Transaction(strDate, amount);

		e1.persist(wall);
		e1.persist(fund);



		e1.close();
	
	 return walletjpa.getBalance();
		
			
	}

	@Override
	public Walletjpa getAccountdb(String username, String password) throws MPException {
		
		
		boolean flag=false;
		Walletjpa walletjpa=null;
		
		
		
			EntityManagerFactory e=Persistence.createEntityManagerFactory("paymentWalletJPA");
			EntityManager e1=e.createEntityManager();
	
			
	
		
			Walletjpa wall =(Walletjpa)e1.createNativeQuery("select * from walletjpa where username="+"username", Walletjpa.class).getSingleResult();
			
			
					if(username.equals(wall.getUsername())&&password.equals(wall.getPassword())) 
						{
						 walletjpa=new Walletjpa(wall.getUsername(),wall.getPassword(), wall.getBalance());
						flag=true;
						}
		
				

	if(!flag) {
			throw new MPException("Please try again..username or password not correct");
			
			}
		


		return walletjpa;
	}


	public long fundTransfer(Walletjpa walletjpa,long amount1,String customerAccNo) {
		
		EntityManagerFactory e=Persistence.createEntityManagerFactory("paymentWalletJPA");
		EntityManager e1=e.createEntityManager();
		e1.getTransaction().begin();
		
		Walletjpa wall =(Walletjpa)e1.createNativeQuery("select * from walletjpa where username="+"username", Walletjpa.class).getSingleResult();
		
		wall.setBalance(walletjpa.getBalance());
	
		Date date = Calendar.getInstance().getTime();  
		DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");  
		String strDate = dateFormat.format(date);  
    
    
		String amount=Long.toString(amount1);
		amount=amount+"Rs.transferred to wallet";
	

		Transaction fund=new Transaction(strDate, amount);

		e1.persist(wall);
		e1.persist(fund);



		e1.close();

		
	return walletjpa.getBalance();
		
	
	}

	@Override
	public void getTransaction() {
		EntityManagerFactory e=Persistence.createEntityManagerFactory("paymentWalletJPA");
		EntityManager e1=e.createEntityManager();
		e1.getTransaction().begin();
		List<Transaction> res = e1.createQuery("FROM FundTransaction", Transaction.class).getResultList();
		System.out.println(res);
		
		e1.close();
	
	}

	@Override
	public boolean addUser(Walletjpa walletjpa) {
		
	
		
		EntityManagerFactory e=Persistence.createEntityManagerFactory("paymentWalletJPA");
		EntityManager e1=e.createEntityManager();
		e1.getTransaction().begin();
		
	Walletjpa wall=new Walletjpa(walletjpa.getUsername(), walletjpa.getPassword(), walletjpa.getBalance());
		e1.persist(wall);
		
		
		e1.getTransaction().commit();
		e.close();
		
	

		return true;
	}

	@Override
	public void createAccount(Customer customer) throws MPException {
		
	
	
			EntityManagerFactory e=Persistence.createEntityManagerFactory("paymentWalletJPA");
			EntityManager e1=e.createEntityManager();
			e1.getTransaction().begin();
			
		Customer cust=new Customer(customer.getCustomerName(), customer.getCustomerPhone(), customer.getCustomerAddress(), customer.getCustomerAdhar());
			

			e1.persist(cust);
			
			
			e1.getTransaction().commit();
			e.close();
			
			
			
	}
}
		
