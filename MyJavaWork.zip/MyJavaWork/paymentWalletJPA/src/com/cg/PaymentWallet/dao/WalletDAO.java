package com.cg.PaymentWallet.dao;



import java.util.Date;
import java.util.Map;

import com.cg.PaymentWallet.Exception.MPException;
import com.cg.PaymentWallet.dto.Customer;
import com.cg.PaymentWallet.dto.Walletjpa;




public interface WalletDAO {
	
	
	long deposit(Walletjpa walletjpa, long amount1);
	long withdraw(Walletjpa walletjpa, long amount1);
	Walletjpa getAccountdb(String walletId, String passkey) throws MPException;
	long fundTransfer(Walletjpa walletjpa, long amount1,String customerAccNo);
	void getTransaction();
	boolean addUser(Walletjpa walletjpa);
	void createAccount(Customer customer)throws MPException;
	

}
