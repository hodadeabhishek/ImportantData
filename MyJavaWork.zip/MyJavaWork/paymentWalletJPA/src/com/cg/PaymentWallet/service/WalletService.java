package com.cg.PaymentWallet.service;

import java.util.Date;
import java.util.Map;

import com.cg.PaymentWallet.Exception.MPException;
import com.cg.PaymentWallet.dto.Customer;
import com.cg.PaymentWallet.dto.Walletjpa;


public interface WalletService {

	Walletjpa valideLogin(String walletId, String passkey) throws MPException;

	void validateAmount(long amount) throws MPException;

	long depositMoney(Walletjpa walletjpa, long amount1);

	void validateMoneyDr(long moneyDr) throws MPException;

	long withdrawMoney(Walletjpa walletjpa, long amount1);

	void validateFundAmount(long fundAmount) throws MPException;

	long fundTransfer(Walletjpa walletjpa, long amount1, String customerAccNo);

	void getTransaction();

	

	void validatePassword(String password) throws MPException;

	boolean adduser(Walletjpa walletjpa);

	void validateName(String customerName) throws MPException;

	void validateAddress(String customerAddress)throws MPException;

	void validatePhone(String customerPhone)throws MPException;

	void validateAdhar(String customerAdhar)throws MPException;

	void createAccount(Customer customer) throws MPException;

	void validateAccNo(String customerAccNo)throws MPException;;

	

	

	

	


	
	

}
