package com.cg.EmployeeRegistration.Employee;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegistrationServelet
 */
@WebServlet("/RegistrationServelet")
public class RegistrationServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	Connection c;
	Statement stmt=null;
	ResultSet rs=null;
    public RegistrationServelet() {
        // TODO Auto-generated constructor stub
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		
		PrintWriter out=response.getWriter();
		
		String fname=request.getParameter("fn");
		String lname=request.getParameter("ln");
		String email=request.getParameter("ed");
		String mobile=request.getParameter("mo");
		String location=request.getParameter("lo");
		
		out.println("<h2>Welcpme to Employee Registration Form <h2>");
		out.println("<h3>Whoo! Mr.<strong>"+lname+"</strong> you have have successfully registraion<h3>" );
		out.println("<h3>Your Dtails <h3>");
		out.println("<h4>First Name:<strong>"+fname+"</strong><h4>");
		out.println("<h4>Last Name:<strong>"+lname+"</strong><h4>");
		out.println("<h4>Email:<strong>"+email+"</strong><h4>");
		out.println("<h4>Mobile:<strong>"+mobile+"</strong><h4>");
		out.println("<h4>Location:<strong>"+location+"</strong><h4>");
		
		
		
	try {
		
		Class.forName("oracle.jdbc.OracleDriver");
		
		 c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "System", "India123");
		
		
		PreparedStatement pst=c.prepareStatement("insert into EmployeeServlet1(id,firstname,lastname,email,mobile,location) values(employee_seq.nextval,?,?,?,?,?)");
		
		System.out.println("connection setup okay");
		
		
		pst.setString(1,fname);
		pst.setString(2,lname);
		pst.setString(3,email);
		pst.setString(4,mobile);
		pst.setString(5,location);
		
		pst.executeUpdate();
		pst.close();

		
	     		
	} catch (Exception e) {
		
		System.out.println("problem in connection");
	}
	
	finally 
	{
	try {
		c.close();
		} 
	catch (SQLException e)
	{
	e.printStackTrace();
		}
	}
		
		/*RequestDispatcher rd=request.getRequestDispatcher("loginServlet");  
    rd.forward(request,response);*/
	response.sendRedirect("Login.html");
	
	}

}
