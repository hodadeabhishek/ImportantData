package com.cg.EmployeeRegistration.Employee;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.corba.se.impl.protocol.RequestDispatcherRegistryImpl;

/**
 * Servlet implementation class loginServlet
 */
@WebServlet("/loginServlet")
public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	Connection c;
	ResultSet rs;
	Statement stmt;

	public loginServlet() {
		super();

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");

		PrintWriter out = response.getWriter();

		try {

			Class.forName("oracle.jdbc.OracleDriver");

			c = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "System", "India123");

			System.out.println("connection Ok");
			stmt = c.createStatement();
			rs = stmt.executeQuery("select * from EmployeeServlet1");

			String firstname = request.getParameter("fn1");
			String password = request.getParameter("pw");

			while (rs.next()) {

				if (firstname.equals(rs.getString(2)) && password.equals(rs.getString(5)))
				{
					
					RequestDispatcher rd = request.getRequestDispatcher("welcom.html");
					rd.forward(request, response);
					
				} 
					
					
								}
			
			RequestDispatcher rd = request.getRequestDispatcher("Login.html");
			rd.include(request, response);

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

}
