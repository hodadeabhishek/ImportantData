package Service;

public interface AccountServiceInterface {

}
