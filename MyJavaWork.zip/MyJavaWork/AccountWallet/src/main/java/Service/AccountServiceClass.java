package Service;

import Bean.AccountBean;
import Bean.BankBean;
import Dao.AccountDaoClass;

public class AccountServiceClass {

	AccountDaoClass ADC=new AccountDaoClass();
	AccountBean AB=new AccountBean();
	BankBean bb=new BankBean();
	
	public void GetAccountDetails(BankBean bb)
	{
		
		ADC.storeDetailInMap(bb);
		System.out.println(bb.getAccountNo());
	}
	
	

	
	
	
	public void depositeToWallet(double amount)
	{
	
		
double newWalletBalance=bb.getBalanceW()+amount;
		
		bb.setBalanceW(newWalletBalance);
		
		System.out.println(bb.getBalanceW());
		
		
		
		double Balance=AB.getBalance()-amount;
		AB.setBalance(Balance);
		
		
		System.out.println("account balance is"+AB.getBalance());
		
		
	ADC.depositeToWalletDao(newWalletBalance,Balance);

	
	
		
	}


	public Double showBalance(double ubal) {
		
		return ADC.showBalance(ubal);
	
	}
}
