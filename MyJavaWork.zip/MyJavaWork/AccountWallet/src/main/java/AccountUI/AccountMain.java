package AccountUI;

import java.util.Scanner;

import org.omg.CORBA.portable.ApplicationException;

import Bean.BankBean;
import Service.AccountServiceClass;

public class AccountMain

{
	
	public static void main(String[] args) 
	
	{
		while(true)
		{
		System.out.println("Choose The Option Below");
		System.out.println("1.Create Account");
		System.out.println("2.Show Balance");
		System.out.println("3.Deposite");
		System.out.println("4.Withdraw");
		System.out.println("5.Fund Transfer");
		System.out.println("6.Print Transaction");
		
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		AccountServiceClass accountServiceC=new AccountServiceClass();
		BankBean Bankbean=new BankBean();
		
		switch (n) {
		
		case 1:
			
			System.out.println("Enter The Name");
			String name=sc.next();
			
			System.out.println("Enter  Account number");
			int acn=sc.nextInt();
			
			System.out.println("Enter  Adhar number");
			int adhar=sc.nextInt();
				
			System.out.println("Enter Email address");
			String Eaddrs=sc.next();
			
			System.out.println("Mobile No");
			int mob=sc.nextInt();
			
		

			BankBean bb=new BankBean(name, acn, adhar, Eaddrs, mob, 0);
			
			
			
			accountServiceC.GetAccountDetails(bb);
			
			System.out.println("Account is created Successfully.....!");
				
			
			
		break;
		case 2:
			
			//System.out.println("Enter The Account Number");
			//int AccNo=sc.nextInt();
			System.out.println("Enter Your Account No");
			Scanner sc1=new Scanner(System.in);
			double ubal=sc1.nextDouble();
			System.out.println("Your Current Balance is:-");
			
			
			System.out.println(accountServiceC.showBalance(ubal));
			break;
			
		case 3:
			
			System.out.println("Enter The Amount To Deposit");
			
			double amount=sc.nextDouble();
			System.out.println("Amount Credited Successfully");
			accountServiceC.depositeToWallet(amount);
			
			
			
			
			break;
		case 4:
			
			
			break;
		case 5:
			
			break;
		case 6:
			
			break;

		default:
			break;
		}
		
		}
		
	}
	
	

}
