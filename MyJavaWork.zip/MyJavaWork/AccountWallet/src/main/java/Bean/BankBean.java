package Bean;

public class BankBean
{
	String name;
	long   AccountNo;
	long AdharNo;
	String EmailId;
	long mobileNo;
	double balanceW;
	public BankBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BankBean(String name, long accountNo, long adharNo, String emailId, long mobileNo, double balanceW) {
		super();
		this.name = name;
		AccountNo = accountNo;
		AdharNo = adharNo;
		EmailId = emailId;
		this.mobileNo = mobileNo;
		this.balanceW = balanceW;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getAccountNo() {
		return AccountNo;
	}
	public void setAccountNo(long accountNo) {
		AccountNo = accountNo;
	}
	public long getAdharNo() {
		return AdharNo;
	}
	public void setAdharNo(long adharNo) {
		AdharNo = adharNo;
	}
	public String getEmailId() {
		return EmailId;
	}
	public void setEmailId(String emailId) {
		EmailId = emailId;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public double getBalanceW() {
		return balanceW;
	}
	public void setBalanceW(double balanceW) {
		this.balanceW = balanceW;
	}
	@Override
	public String toString() {
		return "BankBean [name=" + name + ", AccountNo=" + AccountNo + ", AdharNo=" + AdharNo + ", EmailId=" + EmailId
				+ ", mobileNo=" + mobileNo + ", balanceW=" + balanceW + "]";
	}
	

	

}
