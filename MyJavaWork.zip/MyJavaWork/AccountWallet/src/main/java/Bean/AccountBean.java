package Bean;

public class AccountBean {
	
	public long AccNo;
	String Name;
	double balance;
	
	
	
	
	public long getAccNo() {
		return AccNo;
	}
	public void setAccNo(int accNo) {
		AccNo = accNo;
	}

	public String getName() {
		return Name;
	}


	public void setName(String name) {
		Name = name;
	}



	public double getBalance() {
		return balance;
	}


	public void setBalance(double balance) {
		this.balance = balance;
	}



	


	
	public AccountBean() {
	
		AccNo = 123456789;
		Name = "Ranveer";
		balance=100000;
		
		
	

	
	}
}


