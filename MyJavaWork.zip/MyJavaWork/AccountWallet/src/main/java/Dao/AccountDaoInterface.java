package Dao;

public interface AccountDaoInterface {

}
