package Dao;

import java.util.HashMap;
import java.util.Map;



import Bean.AccountBean;
import Bean.BankBean;

public class AccountDaoClass {
	
	AccountBean AB=new AccountBean();
	BankBean bb=new BankBean();
	
	
	private static Map<Long, BankBean> hm=new HashMap<Long, BankBean>();
	private static Map<Long, Double> hm1=new HashMap<Long, Double>();
	public void storeDetailInMap(BankBean bb)
	{
		
		
		hm.put(bb.getAccountNo(), bb);
		
		
		
		
	}

	



	public void depositeToWalletDao(double newWalletBalance, double balance) {
	
	hm1.put(bb.getAccountNo(),newWalletBalance);
	
	
	
		}





	public Double showBalance(double ubal) {
		

		System.out.println(hm1.values());
		
		return null;
		
		
	}
}
