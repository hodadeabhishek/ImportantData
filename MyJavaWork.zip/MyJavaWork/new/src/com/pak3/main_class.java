package com.pak3;

import com.pack2.inter;

import pack1.abstractM;

public class main_class  extends abstractM implements inter

{

	
	public void meth1()
	{
		System.out.println("This is abstract method meth1");
	}
	public void meth2()
	{
		System.out.println("This is abstract method meth2");
	}

	public void meth4()
	{
		System.out.println("This is interface method meth4");
	}
	public void meth5()
	{
		System.out.println("This is interface method meth5");
	}
	
	public static void main(String[] args) {
		
		
		main_class    m=new main_class();

	m.meth1();
	m.meth2();
	m.meth3();
	m.meth4();
	m.meth5();
	
	m.abc();
	inter.xyz();
	
	
		
	}
}
