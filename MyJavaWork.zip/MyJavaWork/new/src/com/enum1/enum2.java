package com.enum1;

public class enum2 {

	
public enum Day{SUNDAY,MONDAY,TUESDAY,WEDNSDAY,THURSDAY,FRIDAY,SATURDAY};


Day day;

public enum2(Day day)
{
	this.day=day;
	
}

public void itlikes()
{
	switch (day) {
	case SUNDAY:
		System.out.println(" Sunday is funday");
		break;
	case MONDAY:
		System.out.println("Monday is boaring");
		break;
	case TUESDAY:
		System.out.println("Tuesday is good");
		break;
	case WEDNSDAY:
		System.out.println("Wednsday is fine");
		break;
	case THURSDAY:
		System.out.println("Thursday is ok ok");
		break;
	case FRIDAY:
		System.out.println("Friday is happy");
		break;
	case SATURDAY:
		System.out.println("Saturday is very happy");
		break;



	default:
		System.out.println("enter valid day");
		break;
	}
}

public static void main(String[] args) {
	
	enum2 firstday=new enum2(Day.SUNDAY);
	firstday.itlikes();
	
	enum2 secondday=new enum2(Day.MONDAY);
	secondday.itlikes();
	
	enum2 thirdday=new enum2(Day.TUESDAY);
	thirdday.itlikes();
	
	enum2 fourthday=new enum2(Day.WEDNSDAY);
	fourthday.itlikes();
	
	enum2 fifthday=new enum2(Day.THURSDAY);
	fifthday.itlikes();
	
	enum2 sixthday=new enum2(Day.FRIDAY);
	sixthday.itlikes();
	
	enum2 seventhday=new enum2(Day.SATURDAY);
	seventhday.itlikes();
}
}
