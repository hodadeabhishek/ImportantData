package com.enum1;

public class emp {

	public static void main(String[] args) {
		
		

}
}