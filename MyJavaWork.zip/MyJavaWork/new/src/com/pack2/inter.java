package com.pack2;

public interface inter {
	public  void meth4();
	public void meth5();

	
	
	default void abc()
	{
		System.out.println("This is defalt method abc in interface ");
	}
	
	static void xyz()
	{
		System.out.println("This is static method xyz in interface ");
	}
}
