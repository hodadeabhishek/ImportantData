import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;

public class SourceReader {
	
	public static void main(String[] args) {
		
		try {
			
			FileReader fr=new FileReader("text1.txt");
			BufferedReader sb=new BufferedReader(fr);
			
			boolean eof=false;
			while (eof!=true) {
				
				String line=sb.readLine();
				
				if(line==null)
					eof=true;
			
			else
			
				System.out.println(line);
			
			}
			sb.close();
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}

}
