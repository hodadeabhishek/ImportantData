package lamdaExp;
 interface MaxFinder {
	
	public int maximum(int num1,int num2);

}
public class LambdaExpression1 {
	
	public static void main(String[] args) {
		
	
	
	MaxFinder obj=(num1,num2)->
	{
		if(num1>num2)
		{
			System.out.println(num1+"is greater number ");
		}
		else
		{
			System.out.println(num2+"is greater number ");
		}
		return 0;
		
	};
	obj.maximum(30, 20);
	

}}
