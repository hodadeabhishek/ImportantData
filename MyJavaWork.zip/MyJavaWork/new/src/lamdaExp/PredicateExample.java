package lamdaExp;

import java.util.function.Predicate;

public class PredicateExample {
	public static void main(String[] args) {
		
		Predicate<String>pr=a->(a.length()<5);
		
		System.out.println(pr.test("abhishek"));
	}

}
                                                              