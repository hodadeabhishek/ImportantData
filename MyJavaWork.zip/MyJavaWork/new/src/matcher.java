import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class matcher {

	public static void main(String[] args) {
		
		Pattern p=Pattern.compile("[0-9]{3}");
		
		Matcher mach=p.matcher("455");
		System.out.println(mach.matches());
	}
}
