package ioe;

import java.io.FileOutputStream;
import java.util.Scanner;

public class Demofileout {
	
	public static void main(String[] args) {
		
	//	byte b[]=new byte[100];
		System.out.println("enter the text");
		String ch="";
		
try {
	
	Scanner sc=new Scanner(System.in);
	ch=sc.next();
	//System.in.read(b);
	
	FileOutputStream fb=new FileOutputStream("text.txt",true);
	fb.write(ch.getBytes());
	fb.write("\r\n".getBytes());
	fb.close();
	
} catch (Exception e) {
	
	e.printStackTrace();
}


	}

}
