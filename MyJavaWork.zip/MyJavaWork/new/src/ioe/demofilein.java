package ioe;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;

public class demofilein {
	
	public static void main(String[] args) {
		
		byte buffer[]=new byte[100];
		
		try {
			
			

		BufferedInputStream bis=new BufferedInputStream( new FileInputStream("text1.txt"));
		bis.read(buffer);
		
			
		String str=new String(buffer);
		System.out.println(str);
			
		} catch (Exception e) {
			
			e.printStackTrace();
			
		}
		
	}

}
