package Date;

import java.net.DatagramSocketImplFactory;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;


public class Testdate {

	public static void main(String[] args) {
		
		
		Date d=new Date();
		
		System.out.println(d);
		
		
		DateFormat df=DateFormat.getDateInstance(DateFormat.LONG);
		System.out.println(df.format(d));
		
		DateFormat germand=DateFormat.getDateInstance(DateFormat.LONG, Locale.GERMAN);
		
		System.out.println(germand.format(d));
		
		SimpleDateFormat sd=new SimpleDateFormat("hh:mm:a");
		
		System.out.println(sd.format(d));
	}
}
