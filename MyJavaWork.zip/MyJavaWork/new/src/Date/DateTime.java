package Date;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Period;

public class DateTime {

	
	public static void main(String[] args) {
		
		
		LocalDate date=LocalDate.now();
		LocalDate birth=LocalDate.of(1996, 11, 29);
		System.out.println(" Date:"+date);
		
		
		
		LocalTime ltime=LocalTime.now();
		System.out.println("Time:"+ltime);
		
		
		int dd=date.getDayOfMonth();
		int mm=date.getMonthValue();
		int yy=date.getYear();
		
		
		System.out.printf("User defined Date:"+"%d-%d-%d",dd,mm,yy);
		
		
		
		
		Period p=Period.between(birth, date);
		System.out.println(+p.getDays()+"/"+p.getMonths()+"/"+p.getYears());
		System.out.println();
		System.out.println();
	}
}
