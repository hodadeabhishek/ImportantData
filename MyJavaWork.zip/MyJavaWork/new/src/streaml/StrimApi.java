package streaml;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class StrimApi {
	public static void main(String[] args) {
		
		
		List<Integer>list=new ArrayList<Integer>();
		
		list.add(8);
		list.add(7);
		list.add(66);
		list.add(87);
		
		List<Integer> list1=list.stream().filter(i->i%2==0).collect(Collectors.toList());
		
		System.out.println(list1);
		
		
		
	}

}
