package pack1;

public class addition 
{
	
	public static void main(String[] args) {
		
		System.out.println("hello");
	}
}
