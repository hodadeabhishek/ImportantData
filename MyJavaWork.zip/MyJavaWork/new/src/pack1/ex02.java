package pack1;

import java.lang.reflect.Array;
import java.util.*;

public class ex02 {
	
	public static void sortc(String[] abc,int n)
	{
		Arrays.sort(abc);
		System.out.println("sorted array by alphabetical order is"+Arrays.toString(abc));
		
		for(int i=0;i<n;i++)
		{
			if(i<(n+1)/2)
			{
				System.out.println(abc[i].toUpperCase());
			}
			else
			{
				System.out.println(abc[i].toLowerCase());
			}
		}
		
	}
	
	public static void main(String[] args) {
		
		System.out.println("Enter the size of array");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		String arr[]= new String[n];
		System.out.println("Enter the array element");
		
		for(int i=0;i<n;i++) {
		arr[i]=sc.next();
		
		}
		sortc(arr,n);
	}

}
