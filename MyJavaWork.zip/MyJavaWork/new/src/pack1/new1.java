package pack1;




	public class new1{


	public static void main(String[] args) {
		
	

	

}}