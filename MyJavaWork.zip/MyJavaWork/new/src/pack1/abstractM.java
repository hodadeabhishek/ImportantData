package pack1;

public abstract class abstractM {

	
	abstract protected void meth1();
	abstract protected void meth2();
	
	public void meth3()
	{
	System.out.println("This is abstract concreate method meth3");	
	}
	
		
	
}
