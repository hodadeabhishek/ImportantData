package pack1;
import java.util.*;



	public class arrChar{


	public static void getcount(String str)

	{
	

	char []c=str.toCharArray();
	



	for(int i=0;i<c.length;i++)
		{
		int count=0;
	
	 	for(int j=0;j<c.length;j++)

			{

			if(j<i&&c[i]==c[j])
				{
			
				break;
				}

			if(c[i]==c[j])
				{
				count++;
				}

			}
	 	
		if(count>0)
		{
		System.out.println(c[i]+"is"+count);

		}

		}




	}
	public static void main(String [] args)
		{

	System.out.println("enter the character in array");

	Scanner sc = new Scanner(System.in);
	String str=sc.nextLine();
	getcount(str);


			


		}
	}


