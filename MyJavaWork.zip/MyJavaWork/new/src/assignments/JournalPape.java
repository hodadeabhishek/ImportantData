package assignments;

public class JournalPape extends WrittenItem{
	
	
 public void JournalPape1()
 {
	 
	 
	 System.out.println("Info about journal paper");
	 JournalPape jp=new JournalPape();
	                jp.setidNum(111);
					jp.setTitle("IEE");
					jp.setAuthor("XYZ");
					jp.setPubYear(2000);
					jp.setPubYear(2010);
					jp.setNumCopies(100);
					
					System.out.println("ID"+" -"+jp.getidNum());
					System.out.println("TITLE"+" -"+jp.getTitle());
					System.out.println("AUTHOR"+" -"+jp.getAuthor());
					System.out.println("YEAR OF PUBLISH"+" -"+jp.getPubYear());
 }


	private int pubYear;
	public int getPubYear() {
		return pubYear;
	}
	
	public void setPubYear(int pubYear) {
		this.pubYear = pubYear;
	}

	}

