package assignments;

import java.util.Scanner;

public class main_class {
	
	static int n,n1,n2;



	public static void main(String[] args) {
		
		video v=new video();
		CD c=new CD();
		JournalPape jp=new JournalPape();
		Book b=new Book();
		
		while(true)
		{
		System.out.println("Enter the choice");
		System.out.println("1.Writtenitem");
		System.out.println("2.Mediaitem");
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		
		if(n==1) {
			System.out.println("WELCOME IN WRITTEN SECTION...!");
			System.out.println("Enter your choice");
			System.out.println("1.BOOK");
			System.out.println("2.JOURNAL");
			n1=sc.nextInt();
		
			
			switch (n1) {
			case 1:
			b.Book();
			break;

			case 2:
				
			jp.JournalPape1();
			
			break;
			
			default:
				
				break;
			}
			
			}
		
		if(n==2)
		{
			System.out.println("WELCOME IN MEDIA ITEMS...!");
			System.out.println("Enter your choice");
			
			System.out.println("1.VIDEO");
			System.out.println("2.CD");
			n2=sc.nextInt();
			
			switch (n2) 
			{
			case 1:
			v.video();
			break;
			
			case 2:
			c.CD();
			break;
			
			default:
			System.out.println("Enter the correct option");
			break;
			}
			
			}
		else
		{
			System.out.println("Enter the correct option");
	
		}
		}
}
}