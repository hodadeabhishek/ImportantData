package assignments;

public class CD {
	private String artist;
	private String gender;
	
	
	public void CD()
	{
		System.out.println("Display info about CD");
		CD c=new CD();
		c.CD();
		c.setArtist("Arman");
		c.setGender("MALE");
		
		System.out.println("Artist Name"+" -"+c.getArtist());
		System.out.println("Artist Age"+" -"+c.getGender());
	}
	public String getArtist() {
		return artist;
	}
	public void setArtist(String artist) {
		this.artist = artist;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}

	
}
