package assignments;

public class video extends MediaItem {

	
	
	public void video()
	{
		video v=new video();
		System.out.println("Display info about video");
		v.setMovie("ram leela");
		v.setDirectior("sanjay leela");
		v.setYrofrelease(2019);
		 
		System.out.println("MOVIE"+" -"+v.getMovie());
		System.out.println("DIRECTOR"+" -"+v.getMovie());
		System.out.println("YEAR OF RELEASE"+" -"+v.getYrofrelease());
	}
	private String movie;
	private String directior;
	
	private int yrofrelease;
	public String getDirectior() {
		return directior;
	}
	public void setDirectior(String directior) {
		this.directior = directior;
	}

	public int getYrofrelease() {
		return yrofrelease;
	}
	public void setYrofrelease(int yrofrelease) {
		this.yrofrelease = yrofrelease;
	}
	public String getMovie() {
		return movie;
	}
	public void setMovie(String movie) {
		this.movie = movie;
	}
	

	
}
