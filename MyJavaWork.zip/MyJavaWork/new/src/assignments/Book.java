package assignments;

public class Book extends WrittenItem {



		public void Book()
		{
			Book b=new Book();
		System.out.println(" Information about a book: ");
		b.setidNum(222);
		b.setTitle("wings of fire");
		b.setAuthor("A.P.");
		b.setNumCopies(500);
		
		System.out.println("ID"+" -"+b.getidNum());
		System.out.println("TITLE"+" -"+b.getTitle());
		System.out.println("AUTHOR"+" -"+b.getAuthor());
		System.out.println("NO OF COPIES"+" -"+b.getCopies());
		
		
		}

}
