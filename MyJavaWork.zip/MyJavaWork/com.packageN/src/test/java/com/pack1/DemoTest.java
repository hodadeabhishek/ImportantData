package com.pack1;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import com.pack.DemoClass;

class DemoTest {

	
	@Test
	void addTest() {
		DemoClass dc=new DemoClass();
		int res=dc.add(5, 3);
		assertEquals(8,res);
	}

}
