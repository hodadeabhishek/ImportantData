package com.pack;

public class DemoClass {
	
	public int add(int a,int b)
	{
		return a+b;
	}

}
