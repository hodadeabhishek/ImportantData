package com.cg.PaymentWallet.service;


import java.util.Date;
import java.util.Map;
import java.util.regex.Pattern;

import com.cg.PaymentWallet.Exception.MPException;
import com.cg.PaymentWallet.dao.WalletDAO;
import com.cg.PaymentWallet.dao.WalletDAOImpl;
import com.cg.PaymentWallet.dto.Customer1;
import com.cg.PaymentWallet.dto.Wallet;






public class WalletServiceImpl implements WalletService {
	
	WalletDAO dao=new WalletDAOImpl();

	@Override
	public Wallet valideLogin(String username, String password) throws MPException {
		
		return dao.getAccountdb(username, password);
	}

	@Override
	public void validateAmount(long amount) throws MPException {
		if(amount<=0) {
			throw new MPException("Amount should be positive Integer");
		}
		
	}

	@Override
	public long depositMoney(Wallet wallet, long amount1) {
		
		
		return dao.deposit(wallet,amount1);
		
		
		
	}

	@Override
	public void validateMoneyDr(long moneyDr) throws MPException {
		
		if(moneyDr<=0) {
			
			throw new MPException("withdraw amount should be positive number");
			
		}
		
	}

	@Override
	public long withdrawMoney(Wallet wallet, long amount1) {
		
		
		return dao.withdraw(wallet,amount1);
	}

	@Override
	public void validateFundAmount(long fundAmount) throws MPException {
		
		if(fundAmount<=0) {
			throw new MPException("Amount should be positive number");
		}
		
		
	}

	@Override
	public long fundTransfer(Wallet wallet,long amount1,String customerAccNo) {
		
		return dao.fundTransfer(wallet,amount1,customerAccNo);
	}

	@Override
	public Map<Date, String> getTransaction() {
		
		return dao.getTransaction();
	}

	@Override
	public void validateUsername(long userName) throws MPException {
		
		if(userName<1000) {
			
			throw new MPException("enter correct name");
		}
		
	}

	@Override
	public void validatePassword(String password) throws MPException {
		
		String regExp="^(?=.*\\d).{4,8}$";
		if(!(Pattern.matches(regExp,password))) {
			throw new MPException("password must contain atleast 8 char/digit");
		}
		
	}

	@Override
	public boolean adduser(Wallet wallet) {
		
		return dao.addUser(wallet);
	}

	@Override
	public void validateName(String customerName) throws MPException {
		String customerNameRegEx = "[A-Za-z ]+";
		if(!Pattern.matches(customerNameRegEx, customerName))
		{
			throw new MPException("Enter alphabets only.");
		}
		
	}

	@Override
	public void validateAddress(String customerAddress) throws MPException {
		String customerAddressRegEx = "[A-Za-z ]+";
		if(!Pattern.matches(customerAddressRegEx, customerAddress))
		{
			throw new MPException("Enter alphabets only.");
		}
		
	}

	@Override
	public void validatePhone(String customerPhone) throws MPException {
		String customerPhoneRegEx = "[7-9]{1}[0-9]{9}";
		if(!Pattern.matches(customerPhoneRegEx, customerPhone))
		{
			throw new MPException("Enter digits only.");
		}
	}

	@Override
	public void validateAdhar(String customerAdhar) throws MPException {
		String customerAdharRegEx = "[0-9]{12}";
		if(!Pattern.matches(customerAdharRegEx, customerAdhar))
		{
			throw new MPException("Enter digits only.");
		}	
		
	}

	@Override
	public void createAccount(Customer1 customer) throws MPException {
		
		dao.createAccount(customer);
		
	}

	@Override
	public void validateAccNo(String customerAccNo) throws MPException {
		String customerPhoneRegEx = "[0-9]{6}";
		if(!Pattern.matches(customerPhoneRegEx, customerAccNo))
		{
			throw new MPException("Enter digits only.");
		}
		
	}

	
	
	

}
