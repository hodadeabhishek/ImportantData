package com.cg.PaymentWallet.service;

import java.util.Date;
import java.util.Map;

import com.cg.PaymentWallet.Exception.MPException;
import com.cg.PaymentWallet.dto.Customer1;
import com.cg.PaymentWallet.dto.Wallet;


public interface WalletService {

	Wallet valideLogin(String walletId, String passkey) throws MPException;

	void validateAmount(long amount) throws MPException;

	long depositMoney(Wallet wallet, long amount1);

	void validateMoneyDr(long moneyDr) throws MPException;

	long withdrawMoney(Wallet wallet, long amount1);

	void validateFundAmount(long fundAmount) throws MPException;

	long fundTransfer(Wallet wallet, long amount1, String customerAccNo);

	Map<Date, String> getTransaction();

	void validateUsername(long userName) throws MPException;

	void validatePassword(String password) throws MPException;

	boolean adduser(Wallet wallet);

	void validateName(String customerName) throws MPException;

	void validateAddress(String customerAddress)throws MPException;

	void validatePhone(String customerPhone)throws MPException;

	void validateAdhar(String customerAdhar)throws MPException;

	void createAccount(Customer1 customer) throws MPException;

	void validateAccNo(String customerAccNo)throws MPException;;

	

	

	

	


	
	

}
