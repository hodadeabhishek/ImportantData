package com.cg.PaymentWallet.Exception;

public class MPException extends Exception {

	public MPException(String msg) {
		
		super(msg);
	
	}
	
	
	

}
