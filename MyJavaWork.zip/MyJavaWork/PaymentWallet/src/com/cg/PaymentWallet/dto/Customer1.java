package com.cg.PaymentWallet.dto;

import java.time.LocalDateTime;

public class Customer1 {

	private String customerName;
	private String customerPhone;
	private String customerAddress;
	private String customerAdhar;

	

	
	public Customer1() {
		super();	
	}

	public Customer1(String customerName, String customerPhone, String customerAddress, String customerAdhar
			) {
		super();
		this.customerName = customerName;
		this.customerPhone = customerPhone;
		this.customerAddress = customerAddress;
		this.customerAdhar = customerAdhar;

	
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustomerAdhar() {
		return customerAdhar;
	}

	public void setCustomerAdhar(String customerAdhar) {
		this.customerAdhar = customerAdhar;
	}


	





	@Override
	public String toString() {
		return "Customer1 [customerName=" + customerName + ", customerPhone=" + customerPhone + ", customerAddress="
				+ customerAddress + ", customerAdhar=" + customerAdhar + "]";
	}

	
}
