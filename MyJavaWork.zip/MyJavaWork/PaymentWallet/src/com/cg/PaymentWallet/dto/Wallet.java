package com.cg.PaymentWallet.dto;

public class Wallet {
	
	
	private String username;
	private String password;
	private long balance;
	
	public Wallet() {
		
	}

	public Wallet(String username, String password, long balance) {
	
		
		this.username = username;
		this.password = password;
		this.balance = balance;
	}



	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long amount) {
		this.balance = amount;
	}

	@Override
	public String toString() {
		return "Wallet [username=" + username + ", password=" + password + ", balance="
				+ balance + "]";
	}
	
	
	
	

}
