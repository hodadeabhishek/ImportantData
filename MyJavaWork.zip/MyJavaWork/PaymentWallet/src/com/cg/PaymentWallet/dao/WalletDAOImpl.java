package com.cg.PaymentWallet.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.PaymentWallet.Exception.MPException;
import com.cg.PaymentWallet.dto.Customer1;
import com.cg.PaymentWallet.dto.Wallet;
import com.cg.PaymentWallet.ui.walletMain;




public class WalletDAOImpl implements WalletDAO {

	
	private static Map<String,Wallet> map=new HashMap<String,Wallet>();
	private static Map<Date,String> wmap=new HashMap<Date,String>();
	private static Map<String, Customer1> custMap=new HashMap<String, Customer1>();


	@Override
	public long deposit(Wallet wallet, long amount1) 
	{
		
	
	map.put(wallet.getUsername(), wallet);
    Date date=new Date();
	String amount=Long.toString(amount1);
	amount=amount+"Rs.credited to wallet";
	wmap.put(date,amount);

		
	return wallet.getBalance();
		
	}

	@Override
	public long withdraw(Wallet wallet,long amount1) {
		
	
		map.put(wallet.getUsername(), wallet);
		
		Date date=new Date();
		
		String amount=Long.toString(amount1);
		
		amount=amount+"Rs.debited from wallet";
		
		wmap.put(date,amount);
		
		
		return wallet.getBalance();
	}

	@Override
	public Wallet getAccountdb(String username, String password) throws MPException {
		
		
		List<Wallet> list=new ArrayList<>(map.values());
		Wallet wallet=null;
		boolean flag=false;
		
		for(Wallet wallet1:list) {
			
			if(wallet1.getUsername().equals(username) && wallet1.getPassword().equalsIgnoreCase(password)) {
				
				wallet=wallet1;
				flag=true;
				break;
			}
		}
		
		if(!flag) {
			
				throw new MPException("Please try again..username or password not correct");
			
		}
		
		return wallet;
	}

	@Override
	public long fundTransfer(Wallet wallet,long amount1,String customerAccNo) {
		
	
		map.put(wallet.getUsername(), wallet);
		
		Date date=new Date();
		String amount=Long.toString(amount1);
		
		walletMain wmain=new walletMain();
		amount=amount+"Rs transfered to Account No:"+customerAccNo;
		
		wmap.put(date,amount);
		
		
	return wallet.getBalance();
		
		
	}

	@Override
	public Map<Date, String> getTransaction() {
		
		return wmap;
	}

	@Override
	public boolean addUser(Wallet wallet) {
		
	map.put(wallet.getUsername(), wallet);
	
		return true;
	}

	@Override
	public void createAccount(Customer1 customer) throws MPException {
		
		custMap.put(customer.getCustomerPhone(), customer);
		
	}



	
	

}
