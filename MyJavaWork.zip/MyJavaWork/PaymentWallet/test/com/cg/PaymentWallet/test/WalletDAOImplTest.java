package com.cg.PaymentWallet.test;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.PaymentWallet.Exception.MPException;
import com.cg.PaymentWallet.dao.WalletDAOImpl;
import com.cg.PaymentWallet.dto.Customer1;
import com.cg.PaymentWallet.dto.Wallet;


class WalletDAOImplTest {

	
	WalletDAOImpl dao;

	Wallet wallet=null;
	@BeforeEach
	void setUp() throws Exception {
		
		WalletDAOImplTest dao=new WalletDAOImplTest();
	}

	@AfterEach
	void tearDown() throws Exception {
		
		dao=null;
	}

	@Test
	void testDeposit() {
		Wallet wallet=new Wallet("abhi", "abhi12345", 5000);


				try {
					dao.deposit(wallet,wallet.getBalance());
	
					}
 catch (Exception e) 
				{

				}


	}

	

		
	


	@Test
	void testWithdraw() {
		Wallet wallet=new Wallet("abhi","abhi12345",5000);

		try {
			
			
			dao.withdraw(wallet, wallet.getBalance());
			assertNotNull(dao);
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	
			

		
	
	
	}


	@Test
	void testFundTransfer() {
	try {
			
			dao.deposit(wallet,wallet.getBalance());

			assertNotNull(dao);
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@Test
	void testAddUser() throws MPException {
		Wallet wall=new Wallet("abhi", "abhi1234", 6000);
		
		dao.addUser(wall);
		assertNull(wall);
	}

	@Test
	void testCreateAccount() {
		Customer1 cust=new Customer1("nandan", "9860543212", "chennai", "987654987654");

		try {
			dao.createAccount(cust);;
			assertNull(cust);
		} catch (MPException e) {

		}
	}

}
