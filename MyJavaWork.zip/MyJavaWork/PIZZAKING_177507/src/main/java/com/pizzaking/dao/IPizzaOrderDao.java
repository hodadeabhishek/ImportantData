package com.pizzaking.dao;

import com.pizzaking.bean.Customer;
import com.pizzaking.bean.PizzaOrder;

public interface IPizzaOrderDao {

	
	public void displayPizzaDetail();
	public PizzaOrder getPizzaDetail(int n);
	public void storeIntoMap(Customer cs);
	public Customer getDetailFromMap(int orderid);
}
