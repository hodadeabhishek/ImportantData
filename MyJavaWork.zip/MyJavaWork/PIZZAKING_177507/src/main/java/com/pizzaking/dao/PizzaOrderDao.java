package com.pizzaking.dao;


import java.util.HashMap;
import java.util.Map;

import com.pizzaking.bean.Customer;
import com.pizzaking.bean.PizzaOrder;



public class PizzaOrderDao implements IPizzaOrderDao{

	
	Map<Integer, Customer> hm=new HashMap<Integer, Customer>();
	Map<Integer, PizzaOrder> hm1=new HashMap<Integer, PizzaOrder>();
	
	


	public  PizzaOrderDao()
	{
		hm1.put(1, new PizzaOrder(1,"Margorita",350)); 
		hm1.put(2, new PizzaOrder(2,"Plane Pizza",250)); 
		hm1.put(3, new PizzaOrder(3,"Cheese Pizza",400)); 
		hm1.put(4, new PizzaOrder(4,"Veg Pizza",300)); 
		hm1.put(5, new PizzaOrder(5,"Non-VegPizza",450)); 

	}
	

	
	//fetching detail printed pizza list
	public void displayPizzaDetail() 
	{
		for(Integer aKey : hm1.keySet())
		{
			PizzaOrder aValue = hm1.get(aKey);
				System.out.println(aValue);	
		}
		
	}

	

//getting pizza detail and return
	public PizzaOrder getPizzaDetail(int n) 
	{
		
		return hm1.get(n);
	}
	
	
//all details stored into map
	public void storeIntoMap(Customer cs) {
		
		hm.put(cs.getOrderId(),cs);
		
	}
//fetching all details from map
	public Customer getDetailFromMap(int orderid) {
		
		return hm.get(orderid);
	}






	}




	
