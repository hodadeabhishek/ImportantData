package com.pizzaking.bean;

import java.util.Date;

public class Customer extends Bill
{
	private String customerName;
	private String CustAddrs;
	private String CustMoNo;
	private int CustId;
	private Date Date;
	private String toping;
	
	
	
	private int orderId;
	private double priceOfPizza;
	private String purchasedate;
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public double getPriceOfPizza() {
		return priceOfPizza;
	}
	public void setPriceOfPizza(double priceOfPizza) {
		this.priceOfPizza = priceOfPizza;
	}
	public String getPurchasedate() {
		return purchasedate;
	}
	public void setPurchasedate(String purchasedate) {
		this.purchasedate = purchasedate;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustAddrs() {
		return CustAddrs;
	}
	public void setCustAddrs(String custAddrs) {
		CustAddrs = custAddrs;
	}
	public String getCustMoNo() {
		return CustMoNo;
	}
	public void setCustMoNo(String custMoNo) {
		CustMoNo = custMoNo;
	}
	public int getCustId() {
		return CustId;
	}
	public void setCustId(int custId) {
		CustId = custId;
	}
	public Date getDate() {
		return Date;
	}
	public void setDate(Date date) {
		Date = date;
	}
	public String getToping() {
		return toping;
	}
	public String setToping(String toping2) {
		this.toping = toping2;
		return CustAddrs;
	}
	@Override
	public String toString() {
		
		return 				
		
		   "CustId: " + getCustId()
		+ "\nCustomer Name: " +getCustomerName()
		+ "\nAddress: " + getCustAddrs()
		+ "\nMobileNumber: " + getCustMoNo()
		+ "\npizza No:" + getPizza()
		+ "\npizza name:" + getPizzaname()
		+"\nToping name you selected: \n"+getToping()
		+ "\npizza price: " + getPriceOfPizza()
		+ "\nTotal pizza price: " + getPizzaprice()
		+ "\npurchase date="+ getPurchasedate();
	}
	
	
	
	
	

}
