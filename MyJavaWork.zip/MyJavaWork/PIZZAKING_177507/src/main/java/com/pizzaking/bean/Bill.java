package com.pizzaking.bean;

public class Bill extends PizzaOrder
{


	
	int orderId;
	double priceOfPizza;
	String purchasedate;
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public double getPriceOfPizza() {
		return priceOfPizza;
	}
	public void setPriceOfPizza(double priceOfPizza) {
		this.priceOfPizza = priceOfPizza;
	}
	public String getPurchasedate() {
		return purchasedate;
	}
	public void setPurchasedate(String purchasedate) {
		this.purchasedate = purchasedate;
	}
	@Override
	public String toString() {
		return "Bill [orderId=" + orderId + ", TotalPrice=" + priceOfPizza + ", purchasedate=" + purchasedate + "]";
	}

	public void Bill() {
		// TODO Auto-generated constructor stub
	}
}
