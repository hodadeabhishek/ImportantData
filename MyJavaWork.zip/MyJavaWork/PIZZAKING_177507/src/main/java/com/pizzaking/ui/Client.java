package com.pizzaking.ui;

import java.util.Scanner;

import com.pizzaking.bean.Customer;
import com.pizzaking.bean.PizzaOrder;
import com.pizzaking.service.PizzaOrderService;





public class Client 
{

	public static void main(String[] args) 
	{
		
		PizzaOrderService pizzaorders=new PizzaOrderService();
		
		while(true)
		{
		
		System.out.println("Choose The  Menu");
		System.out.println("1.Place Order");
		System.out.println("2.Display Order");
		System.out.println("3.Exit");
		
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		
		switch (n) {
		case 1:
			pizzaorders.placeOrder();
		
		break;
		
		case 2:
			System.out.println("Enter Your order ID for your Order Detail");
			
				
			int orderid=sc.nextInt();
			
			Customer rpc1=pizzaorders.getOrderdetails(orderid);
				System.out.println(rpc1);
			break;
			
	 
		case 3:
			System.out.println("Application closed");
			System.exit(0);
			break;
		}
		
	}
	}
}