package com.cg.studentjpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class StudentJPQL {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("FirstJpa");

		EntityManager entityManager = emf.createEntityManager();
		entityManager.getTransaction().begin();


		
		Query query = entityManager.createNamedQuery("getAllStudent");
		List<Student> list = query.getResultList();
		list.stream().forEach(System.out::println);
		entityManager.getTransaction().commit();
		
		
		
		/*Query query = entityManager.createQuery("Select UPPER(stud1.name) from Student stud1");
		List<String> list = query.getResultList();

		list.stream().forEach(System.out::println);
		
	
*/

		entityManager.close();
		emf.close();
		
}
}