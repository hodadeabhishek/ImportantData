package com.cg.studentjpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class StudentJPAcriateria {

	
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("FirstJpa");

		EntityManager entityManager = emf.createEntityManager();
		entityManager.getTransaction().begin();


		
	
		Query query = entityManager.createQuery("select ");
		List<String> list = query.getResultList();

		list.stream().forEach(System.out::println);

		entityManager.close();
		emf.close();
		
}
}
