package com.cg.studentjpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class SaveStudent {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("FirstJpa");

		EntityManager entityManager = emf.createEntityManager();
		entityManager.getTransaction().begin();

		Student stud1 = new Student("1299", "mangesh", " MECHANICAL");
		Student stud2 = new Student("1222", "nagesh", " ELECTRONICS");
		Student stud3 = new Student("1233", "naveen", " ELECTRICAL");
		Student stud4 = new Student("1244", "yogesh", " IT");

		entityManager.persist(stud1);
		entityManager.persist(stud2);
		entityManager.persist(stud3);
		entityManager.persist(stud4);

		
		Query query = entityManager.createNamedQuery("getAllStudent");
		List<Student> list = query.getResultList();
		list.stream().forEach(System.out::println);
		entityManager.getTransaction().commit();
		
		
		
		/*Query query = entityManager.createQuery("Select UPPER(stud1.name) from Student stud1");
		List<String> list = query.getResultList();

		list.stream().forEach(System.out::println);
		
	
*/

		entityManager.close();
		emf.close();
		
		

	}

}
