package DemoCollection;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.TreeSet;
import java.util.Vector;

public class CollectionDemo {
	
	public static void main(String[] args) {
		
		ArrayList<Integer > a1=new ArrayList<Integer>();
		
		a1.add(78);
		a1.add(100);
		a1.add(78);
		
		System.out.println("arraylist"+"your  marks"+a1);
		
		
LinkedList<String> arr=new LinkedList<String>();
		arr.add("balaji");
		arr.add("abhi");
		arr.add("balaji");
		System.out.println("arraylist"+"your name"+arr);
		
		
		
		Vector< String> v=new Vector<String>(arr);
		
		System.out.println("Vector"+"your  names"+v);
		
		
		
		HashSet<String> s1=new HashSet<String>();
		
		s1.add("mango");
		s1.add("orange");
		s1.add("mango");
		System.out.println("hashset"+"fruits"+s1);
		
		TreeSet<String> t1=new TreeSet<String>(s1);
		System.out.println("Treeset"+"fruits"+t1);
		
		System.out.println("t1.equals s1:"+t1.equals(s1));
		Iterator<String> itr=t1.iterator();
		
		
		System.out.println("Iterator Type 1");
		
		while(itr.hasNext())
		{
			String e=(String)itr.next();
			System.out.println(e);
		}
		
		System.out.println("Iterator Type 2");
		
		for(Object o:t1)
		{
			System.out.println(o);
		}

		
		
		
		
}
}