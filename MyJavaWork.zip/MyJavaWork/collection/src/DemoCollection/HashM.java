package DemoCollection;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;

public class HashM {
	public static void main(String[] args) {
		
		
		HashMap<String, Integer>  hashmap=new HashMap<String, Integer>();
		HashMap<String, Integer>  hm=new HashMap<String, Integer>();
		
		hashmap.put("one", new Integer(1));
		hashmap.put("two", new Integer(2));
		hashmap.put("Three", new Integer(3));
		hashmap.put("Three", new Integer(5));
		
		hashmap.put(null, new Integer(4));
		System.out.println(hashmap);
		
		hm.putAll(hashmap);
		System.out.println(hm);
		
	System.out.println("Hashmap contain"+" "+hashmap.size()+" "+"elements");
		
		if(hashmap.containsValue(new Integer(1)))
		{
			System.out.println("hashmap conatain the 1 value");
		}
		else
		{
			System.out.println("hashmap does not contain 1 value");
		}
	
		if(hashmap.containsKey(null))
		{
			System.out.println("hashmap contain null value");
		}
		else
		{
			System.out.println("hashmap does not contain null value");
		}
		
		Integer o=(Integer) hashmap.get("one");
		System.out.println("value mapped with key is"+o);
		
		
		System.out.println("Retriving all keys from the Hashmap");
		
		Iterator<String> iterator=hashmap.keySet().iterator();
		
		while(iterator.hasNext())
		{
			System.out.println(iterator.next());
		}
		
		
		System.out.println("Retriving all key value pairs from hashmap");
		
		Iterator<Map.Entry<String, Integer>> itr=hashmap.entrySet().iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		System.out.println("using enhanced for loop");
		
		for(String aKey:hashmap.keySet())
		{
			Integer aValue=hashmap.get(aKey);
			System.out.println(""+aKey+":"+aValue);
		}
		
		System.out.println("using enhanced for loop for values");
		for(Integer aValue:hashmap.values())
		{
			System.out.println(aValue);
		}
		
		HashSet<String> hs=new HashSet<String>();
		hs.addAll(hashmap.keySet());
		System.out.println("hash set :"+hs);
	}

}
