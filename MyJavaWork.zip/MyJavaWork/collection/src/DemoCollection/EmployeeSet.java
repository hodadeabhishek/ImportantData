package DemoCollection;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class EmployeeSet extends Employee {

	public EmployeeSet(int id, String name) {
		super(id, name);
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		
		HashSet<Employee> hs=new LinkedHashSet<Employee>();
		
		Employee e1=new Employee(100,"abc");
		Employee e2=new Employee(101,"xyz");
		
		hs.add(e1);
		hs.add(e2);
		
		Iterator<Employee> itr=hs.iterator();
		System.out.println("using loop");
		while(itr.hasNext()) 
		{
			Employee e=(Employee)itr.next();
			System.out.println(e.getId());
			System.out.println(e.getName());
			
			
		}
		System.out.println("using enhanced for loop");
		
		for(Employee e:hs){
			System.out.println(e.getId());
			System.out.println(e.getName());
			
			
		}
	}
}
