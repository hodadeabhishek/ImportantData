package com.cg.mobshop.dao.test;

import static org.junit.Assert.*;

import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobshop.dao.MobileDAOImpl;
import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.exception.MSException;

public class MobileDAOImplTest {

	MobileDAOImpl dao=null;
	@Before
	public void setUp() throws Exception {
		dao=new MobileDAOImpl();
		
	}

	@After
	public void tearDown() throws Exception {
		
		dao=null;
	}

	@Test
	public void testGetMobileList() {
		try {
			List<Mobiles> hm=dao.getMobileList();
			
			assertNotNull(hm);
		} catch (MSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	@Test
	public void testDeleteMobile() {
		
		try {
			Mobiles mobile =dao.deleteMobile(101);
			
			assertNotNull(mobile);
		} catch (MSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
