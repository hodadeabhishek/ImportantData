package com.cg.mobshop.dao;

import java.util.List;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.exception.MSException;

public interface MobileDao {

	List<Mobiles> getMobileList() throws MSException;

	Mobiles deleteMobile(int mobcode)throws MSException;

}
