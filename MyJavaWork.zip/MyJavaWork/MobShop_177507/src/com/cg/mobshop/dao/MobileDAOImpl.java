package com.cg.mobshop.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.exception.MSException;
import com.cg.mobshop.util.Util;

public class MobileDAOImpl implements MobileDao{

	@Override
	public List<Mobiles> getMobileList() throws MSException {
		
		
		Map<Integer, Mobiles> hm=Util.getMobileEntries();
		
		Collection<Mobiles>clist=hm.values();
		List<Mobiles>list=new ArrayList<Mobiles>(clist);
		return list;
	}

	@Override
	public Mobiles deleteMobile(int mobcode) throws MSException {
		
		Map<Integer, Mobiles> hm1=Util.getMobileEntries();
		
		
		 
		// Util.setMobileEntries(hm1);
		return  hm1.remove(mobcode);
		
		
	}

}
