package com.cg.mobshop.exception;

public class MSException extends Exception{
	
	public MSException(String message) {
		
		super(message);
		
	}

}
