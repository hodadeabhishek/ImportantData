package com.cg.mobshop.service;

import java.awt.geom.Ellipse2D;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import com.cg.mobshop.dao.MobileDAOImpl;
import com.cg.mobshop.dao.MobileDao;
import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.exception.MSException;
import com.cg.mobshop.util.Util;



public class MobileServiceImpl implements MobileService {

	
	MobileDao mobiledao=new MobileDAOImpl();
	@Override
	public List<Mobiles> getMobileList() throws MSException {
		
		return mobiledao.getMobileList();
	}
	@Override
	public Mobiles deleteMobile(int mobcode) throws MSException {
		
		return mobiledao.deleteMobile(mobcode);
	}
	
	
	    	public static Comparator<Mobiles> mobileName = new Comparator<Mobiles>() {

	 			public int compare(Mobiles s1, Mobiles s2) {
	 			   String mobileName1 = s1.getName().toUpperCase();
	 			   String mobileName2 = s2.getName().toUpperCase();

	 			  return mobileName1.compareTo(mobileName2);

	 			     }};
	 			
	 			
	     
	    
	 			    public static Comparator<Mobiles> mobilePrice = new Comparator<Mobiles>() {

	    			public int compare(Mobiles s1, Mobiles s2) {
	    			   Double mobileName1 = s1.getPrice();
	    			   Double mobileName2 = s2.getPrice();

	    			  
	    			   return mobileName1.compareTo(mobileName2);

	    			     }};
	    
	    			     
	     
	      public static Comparator<Mobiles> mobileQuantity = new Comparator<Mobiles>() {

		    		public int compare(Mobiles s1, Mobiles s2) {
		    		  Integer mobileName1 = s1.getQuantity();
		    		   Integer mobileName2 = s2.getQuantity();
		    		   
		    		   return mobileName1.compareTo(mobileName2);

   			     }};
	     
	
		

	
		    		     
}
