package com.cg.mobshop.service;

import java.util.List;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.exception.MSException;

public interface MobileService {

	List<Mobiles> getMobileList() throws MSException;

	Mobiles deleteMobile(int mobcode) throws MSException;

	

}
