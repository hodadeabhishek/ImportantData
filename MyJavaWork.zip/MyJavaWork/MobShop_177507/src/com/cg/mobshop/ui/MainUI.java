package com.cg.mobshop.ui;



import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;


import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.exception.MSException;
import com.cg.mobshop.service.MobileService;
import com.cg.mobshop.service.MobileServiceImpl;
import com.cg.mobshop.util.Util;




public class MainUI {

	
	public static void main(String[] args)
	
	{
		Scanner scanner = null;

		

		String continueChoice = "";

		do {

			
			MobileService service=new MobileServiceImpl();
			
			
			System.out.println("*****Welcome to Mobile shopee***** ");
			
			List<Mobiles> list=null;
			try {
				list=service.getMobileList();
				System.out.println(list.toString().replaceAll("[\\[\\],]",""));
				
				
			} catch (MSException e) {
				
				e.printStackTrace();
			}
			
			
			
			
	
		
			System.out.println("Enter Your Choice");
			System.out.println("1.Sorting");
			System.out.println("2.Delete");
			System.out.println("3.exit");
		
			

			int choice = 0;
			boolean choiceFlag = false;

			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter your choice");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;

					switch (choice) {

					case 1:

						System.out.println("Select Sorting criteria");
						
						System.out.println("1.mobile Name");
						System.out.println("2.mobile Price");
						System.out.println("3.Mobile Quantity");
						System.out.println("Enter option");
						
						Scanner scanner1 = new Scanner(System.in);
						
						
							int criteria = scanner1.nextInt();
						switch (criteria) {
						case 1:
							Map<Integer, Mobiles> Mobile = null;
							
								Mobile = Util.getMobileEntries();
								
								Collection<Mobiles> prod=Mobile.values();
								List<Mobiles>list2=new ArrayList(prod);
								Collections.sort(list2, MobileServiceImpl.mobileName);
								System.out.println(list2.toString().replaceAll("[\\[\\],]",""));
									
							break;
							
						case 2:
							Map<Integer, Mobiles> Mobile1 = null;
							
							Mobile = Util.getMobileEntries();
							
							Collection<Mobiles> prod1=Mobile.values();
							List<Mobiles>list3=new ArrayList(prod1);
							Collections.sort(list3, MobileServiceImpl.mobilePrice);
							System.out.println(list3.toString().replaceAll("[\\[\\],]",""));
							
							break;
							
						case 3:
	
							Map<Integer, Mobiles> Mobile2 = null;
							
							Mobile = Util.getMobileEntries();
							
							Collection<Mobiles> prod2=Mobile.values();
							List<Mobiles>list4=new ArrayList(prod2);
							Collections.sort(list4, MobileServiceImpl.mobileQuantity);
							System.out.println(list4.toString().replaceAll("[\\[\\],]",""));
							break;

						default:
							break;
						}

						break;
						

						
					case 2:

						int mobcode = 0;
						boolean mobileIdFalg = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Mobile Id:");
							try {
								mobcode = scanner.nextInt();
								mobileIdFalg = true;
								Mobiles mobileData;
								try {
									mobileData = service.deleteMobile(mobcode);
									System.out.println("You Delete following Mobile Successfully");
									System.out.println(mobileData);
									
									
									
								
									
								} catch (MSException e1) {
									System.err.println(e1.getMessage());
								}

							} catch (InputMismatchException e) {
								mobileIdFalg = false;
								System.err.println("Id should be digits");
							}
						} while (!mobileIdFalg);

						break;


					

					
						case 3:
							System.out.println("*** Thank you *** ");
							System.exit(0);
							break;

						default:
							choiceFlag = false;
							System.out.println("input should be 1, 2 or 3");
							break;
						}

					} catch (InputMismatchException e) {
						choiceFlag = false;
						System.err.println("please enter only digits");
					}

				} while (!choiceFlag);

				scanner = new Scanner(System.in);
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();

		} while (continueChoice.equalsIgnoreCase("yes"));
			scanner.close();
		}


			
		}