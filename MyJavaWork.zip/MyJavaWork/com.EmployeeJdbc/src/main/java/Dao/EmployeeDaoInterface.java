package Dao;

import java.sql.SQLException;
import java.util.Map;

import Bean.Employee;

public interface EmployeeDaoInterface {
	void storeIntoMap(Employee e);
	 Map<Integer, Employee> displayDetailfromMap() throws SQLException;
	 Employee getSchemefromMap1(int id);
}
