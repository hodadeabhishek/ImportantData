package Dao;
import service.EmployeeService;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;



import Bean.Employee;
import JdbcConnection.CommonCon;

public class EmployeeDao implements EmployeeDaoInterface{
	static Map<Integer, Employee> hm=new HashMap<Integer, Employee>();
	
	
	Employee e=new Employee();
	Connection c=null;
	Statement stmt=null;
	ResultSet rs=null;
	
	
	public void storeIntoMap(Employee e) {
		
			try {
			
			c=CommonCon.getCon();
			
			
			PreparedStatement pst=c.prepareStatement("insert into employee1 values(?,?,?,?)");
			
			
			pst.setInt(1, e.getId());
			pst.setString(2, e.getName());
			pst.setDouble(3, e.getSalary());
			pst.setString(4, e.getDesignation());
			
			
			pst.executeUpdate();
			pst.close();
			
			} 
		
		catch (Exception e2)
		{
			System.out.println(e);
		}
		
	}
	
	
public Map<Integer,Employee>displayDetailfromMap() throws SQLException
	{
		
		c=CommonCon.getCon();
		stmt=c.createStatement();
		rs=stmt.executeQuery("select * from employee1");
		
		while(rs.next())
		{
			e.setId(rs.getInt(1));
			e.setName(rs.getString(2));
			e.setSalary(rs.getDouble(3));
			e.setDesignation(rs.getString(4));
			hm.put(e.getId(), e);
			
		}
		
	
		
		return hm;
	}
	
	public Employee getSchemefromMap1(int id)
	{
		try {
			
			c=CommonCon.getCon();
			
			PreparedStatement pst1=c.prepareStatement("select * from employee where id=?");
			
			pst1.setInt(1, id);
		rs=	pst1.executeQuery();
		
		while(rs.next()) 
		{
			
			e.setId(rs.getInt(1));
			e.setName(rs.getString(2));
			e.setSalary(rs.getDouble(3));
			e.setDesignation(rs.getString(4));
			
			
			
		}
		hm.put(e.getId(), e);
			
			
			pst1.close();
		} 
		
		
		catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		return new Employee();
	}


		
	}
	



