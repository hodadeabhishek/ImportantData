package service;

import java.sql.SQLException;
import java.util.Map;

import Bean.Employee;
import Dao.EmployeeDao;

public class EmployeeService implements EmployeeServiceInterface {

	   EmployeeDao EmpD=new EmployeeDao();
	
	public void storeEmployee(Employee e)
	{
		
		 
			if(e.getSalary()>5000&&e.getDesignation().equals("System Associate"))
			{
				e.setInsuranceScheme("Scheme C");
			}
			else if(e.getSalary()>20000&&e.getDesignation().equals("programmer")) 
			{
				e.setInsuranceScheme("Scheme B");
			}
			else if(e.getSalary()>40000&&e.getDesignation().equals("Manager"))
			{
				e.setInsuranceScheme("Scheme A");
			}
			else
			{
				e.setInsuranceScheme("No scheme");
			}
			
		EmpD.storeIntoMap(e);
		
	}

	

	 public   Map<Integer,Employee>displayDetail()
	 {
		 Map<Integer, Employee> hm1 = null;
	 

	try 
	{
		hm1 = EmpD.displayDetailfromMap();
		
	} 
	
	catch (SQLException e) {
	
		e.printStackTrace();
	}
	
	return hm1;
	
	 
	 }

 
	 public  Employee getScheme(int id)
	 {
		 
		 
	 Employee hm1 = EmpD.getSchemefromMap1(id);
		 
	return hm1;
		 
	 }

}