package service;

import java.util.Map;

import Bean.Employee;

public interface EmployeeServiceInterface {

	Map<Integer, Employee>displayDetail();
	void storeEmployee(Employee e);
	Employee getScheme(int id);
}
