package Bean;

public class AccountBean {

}
