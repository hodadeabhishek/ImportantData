package JdbcConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CommonCon {
	
	static Connection c;
	
	public static Connection  getCon() throws SQLException
	{
		
		try
		{
			Class.forName("oracle.jdbc.OracleDriver");
			
			if(c==null)
			{
				c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "System", "India123");
				
				System.out.println("Connected"+c);
			}
			
			
			
			
		} 
		
		catch (Exception e) 
		{
			System.out.println(e);
		}
		
		
		
		return c;
		
		
		
		
	}
	

}
