package Dao;
import service.EmployeeService;

import java.util.HashMap;
import java.util.Map;

import Bean.Employee;

public class EmployeeDao implements EmployeeDaoInterface{
	static Map<Integer, Employee> hm=new HashMap<Integer, Employee>();

	public void storeIntoMap(Employee e) {
		
		hm.put(e.getId(), e);
		
		 
		if(e.getSalary()>5000&&e.getDesignation().equals("System Associate"))
		{
			e.setInsuranceScheme("Scheme C");
		}
		else if(e.getSalary()>20000&&e.getDesignation().equals("programmer")) 
		{
			e.setInsuranceScheme("Scheme B");
		}
		else if(e.getSalary()>40000&&e.getDesignation().equals("Manager"))
		{
			e.setInsuranceScheme("Scheme A");
		}
		else
		{
			e.setInsuranceScheme("No scheme");
		}
		
	}
	
	
	public Map<Integer,Employee>displayDetailfromMap()
	{
		return hm;
	}
	
	public Employee getSchemefromMap1(int id)
	{
		return new Employee();
	}


	
	}
	

