package Dao;

import java.util.Map;

import Bean.Employee;

public interface EmployeeDaoInterface {
	void storeIntoMap(Employee e);
	 Map<Integer,Employee>displayDetailfromMap();
	 Employee getSchemefromMap1(int id);
}
