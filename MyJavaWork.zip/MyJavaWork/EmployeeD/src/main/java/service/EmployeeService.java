package service;

import java.util.Map;

import Bean.Employee;
import Dao.EmployeeDao;

public class EmployeeService implements EmployeeServiceInterface {

	   EmployeeDao EmpD=new EmployeeDao();
	
	public void storeEmployee(Employee e)
	{
		

		EmpD.storeIntoMap(e);
		
	}

	

	 public   Map<Integer,Employee>displayDetail()
	 {
	 
	 
	 Map<Integer, Employee>hm=EmpD.displayDetailfromMap();
	 return hm;
	 }

 
	 public  Employee getScheme(int id)
	 {
		 Map<Integer, Employee>hm1=EmpD.displayDetailfromMap();
		 
		 
		 return hm1.get(id);
		 
	 }
}
