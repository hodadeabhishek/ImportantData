package UI;

import java.util.Map;
import java.util.Scanner;

import Bean.Employee;
import service.EmployeeService;

public class Main {

	
public static void main(String[] args) 
{
	Scanner sc=new Scanner(System.in);

	
	
	
	while(true)
	{
		System.out.println("Enter your choice");
	System.out.println("1.Get Employee Detail ");
	System.out.println("2.Find Insurance Scheme");
	System.out.println("3.Display Employee Detail");
	System.out.println("4. Exit");
	
	
	int n=sc.nextInt();
	

	EmployeeService  employeeService =new EmployeeService ();
	
	
	switch (n) {
	case 1:
		
		System.out.println("Enter the number of employee you want to add");
		int count=sc.nextInt();
		
		Employee e[]=new Employee[count];
		
		for(int i=0;i<count;i++)
		{
			e[i]=new Employee();
			System.out.println("Enter  id");
			int id=sc.nextInt();
				
			System.out.println("set Name");
			String sname=sc.next();
				
			System.out.println("set Salary");
			double salary=sc.nextDouble();
				
			System.out.println("Enter designation");
			String Desig=sc.next();
			System.out.println(Desig);
				
			
				
			e[i].setId(id);
			e[i].setName(sname);
			e[i].setSalary(salary);
			e[i].setDesignation(Desig);
			
				
			EmployeeService es=new EmployeeService();
			es.storeEmployee(e[i]);
				
			System.out.println("successfully Added details");
		}
		break;

case 2:
	System.out.println("Enter The EmpId");
	
	int  searchId=sc.nextInt();
		
	Employee e1=employeeService.getScheme(searchId);
	
	System.out.println(e1.getName()+" "+e1.getInsuranceScheme());
	
		break;
case 3:

	Map<Integer, Employee>hm= employeeService.displayDetail();
	System.out.println(hm);
	break;
	default:
		break;
	}

}
}
}