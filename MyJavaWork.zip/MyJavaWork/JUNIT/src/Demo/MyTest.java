package Demo;




import static org.testng.AssertJUnit.assertEquals;
import org.junit.jupiter.api.Test;

public class MyTest {

	Myclass obj=new Myclass();
	
	@Test
	void addTest()
	{
		int res=obj.add(5, 3);
		assertEquals(8,res);
	}
	
	void concat()
	{
		String res=obj.concat("helloworld", "hello");
		assertEquals("helloworld",res);
	}

}
