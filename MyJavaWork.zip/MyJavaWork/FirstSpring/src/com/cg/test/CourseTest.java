package com.cg.test;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.spring.Course;

public class CourseTest {
	
	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("spring1.xml");
		
		Course course=(Course) context.getBean("course1");
		
		
		
		System.out.println(course);
	}

}
