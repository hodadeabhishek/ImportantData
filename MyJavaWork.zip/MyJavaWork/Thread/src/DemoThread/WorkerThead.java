package DemoThread;

import org.omg.CORBA.PRIVATE_MEMBER;

public class WorkerThead implements Runnable{

	private String command;
	
	public WorkerThead(String s)
	{
		this.command=s;
	}
	
	@Override
	public void run() 
	{
		
		System.out.println(Thread.currentThread().getName()+"");
		processCommand();
		System.out.println(Thread.currentThread().getName()+"");
	
	}
	
	private void processCommand()
	{
		
		try {
			Thread.sleep(5000);
			} 
		
		catch (InterruptedException e)
		
		{
			e.printStackTrace();
		}
		
		
	}

	@Override
	public String toString() {
		return this.command;
	}

}
