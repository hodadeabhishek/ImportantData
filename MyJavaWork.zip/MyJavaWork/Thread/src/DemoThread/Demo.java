package DemoThread;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Demo extends Thread{


		
		public void run()
		{
			
 
		try {
			FileReader fr = new FileReader("copy1.txt");
			BufferedReader br = new BufferedReader(fr);
			FileWriter fw = new FileWriter("output.txt", true);
			String s=br.readLine();
			int count = 0;
				while(s!=null)
					{
			
					if(!(s.equals(" ")))
					{
						count+=s.length();
					}
				
					char ch[]=s.toCharArray();
					fw.write(ch); 
					s=br.readLine();
					}
			
			int num=count/10;
				for(int i=0;i<num;i++)
				{
				System.out.println("10 character printed");
				Thread.sleep(5000);
				}
				System.out.println("File is copied");
		
		br.close();
		fw.close();
                       
		} catch (Exception e) {
		
			e.printStackTrace();
		}
	
	
	}
		
		public static void main(String[] args) 
		{
			
			Demo dm=new Demo();
			Thread th=new Thread(dm);
			th.start();
		}
}

