package DemoThread;

public class UsingRunnable implements Runnable {

	public void run() {
	
		try {
			
			for(int i=5;i>0;i--)
			{
				System.out.println("chilethread"+i);
				
				Thread.sleep(3000);
			}
			
		} catch (Exception e) {
			System.out.println("child interrupted.");
			
			System.out.println("exiting child thread");
		}
	}
	
	public static void main(String[] args) {
		
		//NewThrad nt=new NewThrad();
		UsingRunnable us=new UsingRunnable();
		Thread th=new Thread(us);
		
		th.setName("Demo Thread");
		System.out.println("child thread"+th);
		
		th.start();
		
		try {
			
			for(int i=5;i>0;i--)
			{
				System.out.println("Main Thread "+i);
				Thread.sleep(3000);
			}
			
		} catch (Exception e) {
			System.out.println("Main Thread Interrupted");
		}
		
		System.out.println("Main thread exiting..");
	}
}


