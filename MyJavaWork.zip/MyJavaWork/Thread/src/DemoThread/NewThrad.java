package DemoThread;

public class NewThrad extends Thread {


	public void run() {
	
		try {
			
			for(int i=5;i>0;i--)
			{
				System.out.println("chilethread"+i);
				
				Thread.sleep(300);
			}
			
		} catch (Exception e) {
			System.out.println("child interrupted.");
			
			System.out.println("exiting child thread");
		}
	}
	
	public static void main(String[] args) {
		
		NewThrad nt=new NewThrad();
		nt.setName("Demo Thread");
		System.out.println("child thread"+nt);
		
		nt.start();
		
		try {
			
			for(int i=5;i>0;i--)
			{
				System.out.println("Main Thread "+i);
				Thread.sleep(300);
			}
			
		} catch (Exception e) {
			System.out.println("Main Thread Interrupted");
		}
		
		System.out.println("Main thread exiting..");
	}
}
