package DemoThread;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileCopyExample {
	 
	public static void main(String[] args) {
		 System.out.println("file copied");
		try {
			FileReader fr = new FileReader("copy1.txt");
			BufferedReader br = new BufferedReader(fr);
			FileWriter fw = new FileWriter("output.txt", true);
			String s;
 
			while ((s = br.readLine()) != null)
			{ 
					
				char c[]=s.toCharArray();
				int count;
				int j = 1;
				while(j<c.length)
				{
			
				for(int i=1;i<=j;i++)
					{
					count=0;
					
					fw.write(c[i]);
					count++;
				
					if(count==j*10)
					{
					break;
					}
				
				
					}
					System.out.println("10 character printed");
					j++;
		}
				  
			
				fw.flush();
			}
			br.close();
			fw.close();
                     
                       
			}	catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

