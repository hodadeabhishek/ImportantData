package com.jdbc1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SecondJdbc {

	
public static void main(String[] args) {
		
		Connection c=null;
		Statement stmt=null;
		ResultSet rs=null;
		
		
		try 
		{
			c=CommonCon.getCon();
			
			/*PreparedStatement pst=c.prepareStatement("insert into book_master(book_code,book_name,book_pub_year,book_pub_author)"
					+"values(?,?,?,?)");
			
			pst.setInt(1, Integer.parseInt(args[0]));
			pst.setString(2, args[1]);
			pst.setInt(3, Integer.parseInt(args[2]));
			pst.setString(4, args[3]);
			*/
			
			PreparedStatement pst1=c.prepareStatement("update book_master set book_name=? where book_code=?");
			
			
			pst1.setString(1, args[0]);
			
			pst1.setInt(2, Integer.parseInt(args[1]));
	
			pst1.executeUpdate();
			
			
			pst1.close();
		} 
		catch (Exception e)
		
		{

			System.out.println(e);
		}
		
		finally 
		{
			try {
				
				c.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		
	}

}

	

