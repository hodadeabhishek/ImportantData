package com.jdbc1;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class callable {


	public static void main(String[] args) {
		
		Connection c=null;
		Statement stmt=null;
		ResultSet rs=null;
		
		try {
				
				c=CommonCon.getCon();
				stmt=c.createStatement();
				
				CallableStatement cs=c.prepareCall("{call proc}");
				cs.execute();
			}
				
			 catch (Exception e) {
				System.out.println(e);
				
			}

}
}