package com.jdbc1;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class FirstJdbc {
	
	public static void main(String[] args) {
		
		Connection c=null;
		Statement stmt=null;
		ResultSet rs=null;
		
		
		try 
		{
			c=CommonCon.getCon();
			stmt=c.createStatement();
			
			rs=stmt.executeQuery("select staff_code,staff_name,staff_sal from staff_master");
			
			while(rs.next())
			{
				System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getDouble(3));
			}
			
		} 
		catch (Exception e)
		
		{

			System.out.println(e);
		}
		
		finally 
		{
			try {
				c.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		
	}

}
