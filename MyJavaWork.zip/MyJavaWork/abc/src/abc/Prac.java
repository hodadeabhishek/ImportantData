package abc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.TreeMap;
import java.util.TreeSet;

public class Prac {

	private static int a=10;
	
	public static void main(String[] args) {
		
HashSet<Integer>a=new HashSet<Integer>();
a.add(null);
a.add(null);
System.out.println(a);
}

	
	
	}

