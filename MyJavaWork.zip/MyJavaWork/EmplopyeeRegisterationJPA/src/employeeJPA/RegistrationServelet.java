package employeeJPA;
import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



@WebServlet("/RegistrationServelet")
public class RegistrationServelet extends HttpServlet {

public static void main(String[] args) {
	
	
}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	response.setContentType("text/html");
		
		PrintWriter out=response.getWriter();
		
		String fname=request.getParameter("fn");
		String lname=request.getParameter("ln");
		String email=request.getParameter("ed");
		String mobile=request.getParameter("mo");
		String location=request.getParameter("lo");
		
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("FirstJpa");
		
		EntityManager entityManager=emf.createEntityManager();
		
		entityManager.getTransaction().begin();
	
		
		/*Customer customer1=new Customer();
		customer1.setId("601");
		customer1.setAddress("delhi");
		customer1.setName("Punjab");*/
		
		entityManager.persist();
		
		
		entityManager.getTransaction().commit();
		
		entityManager.close();
		emf.close();
		
	
	}

}
