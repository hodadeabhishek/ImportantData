package com.cg.PaymentWallet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.PaymentWallet.Exception.MPException;
import com.cg.PaymentWallet.dto.Customer1;
import com.cg.PaymentWallet.dto.Wallet;
import com.cg.PaymentWallet.ui.walletMain;

import JdbcConnection.CommonCon;




public class WalletDAOImpl implements WalletDAO {
	Connection c=null;
	Statement stmt=null;
	ResultSet rs=null;
	
	private static Map<String,Wallet> map=new HashMap<String,Wallet>();
	private static Map<Date,String> wmap=new HashMap<Date,String>();
	private static Map<String, Customer1> custMap=new HashMap<String, Customer1>();
	@Override
	public int checkBalance() {
		
		return 0;
	}

	@Override
	public long deposit(Wallet wallet, long amount1) 
	{
		
	
	map.put(wallet.getUsername(), wallet);
    Date date=new Date();
	String amount=Long.toString(amount1);
	amount=amount+"Rs.credited to wallet";
	wmap.put(date,amount);

		
	return wallet.getBalance();
		
	}

	@Override
	public long withdraw(Wallet wallet,long amount1) {
		
	
		map.put(wallet.getUsername(), wallet);
		
		Date date=new Date();
		
		String amount=Long.toString(amount1);
		
		amount=amount+"Rs.debited from wallet";
		
		wmap.put(date,amount);
		
		
		return wallet.getBalance();
	}

	@Override
	public boolean getAccountdb(String username, String password) throws MPException {
		
		
		boolean flag=false;
		
		try {
			c=CommonCon.getCon();
			Statement stmt = c.createStatement();
			rs = stmt.executeQuery("select * from wallet");
			
			
				while (rs.next()) 
				{
					if(username.equals(rs.getString(1))&&password.equals(rs.getString(2))) 
						{
						
						flag=true;
						break;
						}
				}
			}
		catch (SQLException e) 
			{
			System.out.println(e);
			}
		

if(!flag) {
			throw new MPException("Please try again..username or password not correct");
			
			}
		
		return flag;
	}

	
	/*public Wallet getAccountdb(String username, String password) throws MPException {
		
		try {
			c=CommonCon.getCon();
			Statement stmt = c.createStatement();
			rs = stmt.executeQuery("select * from wallet");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<Wallet> list=new ArrayList<>(map.values());
		Wallet wallet=null;
		boolean flag=false;
		
		for(Wallet wallet1:list) {
			
			if(wallet1.getUsername().equals(username) && wallet1.getPassword().equalsIgnoreCase(password)) {
				
				wallet=wallet1;
				flag=true;
				break;
			}
		}
		
		if(!flag) {
			
				throw new MPException("Please try again..username or password not correct");
			
		}
		
		return wallet;
	}*/
	public long fundTransfer(Wallet wallet,long amount1,String customerAccNo) {
		
	
		map.put(wallet.getUsername(), wallet);
		
		Date date=new Date();
		String amount=Long.toString(amount1);
		
		walletMain wmain=new walletMain();
		amount=amount+"Rs transfered to Account No:"+customerAccNo;
		
		wmap.put(date,amount);
		
		
	return wallet.getBalance();
		
		
	}

	@Override
	public Map<Date, String> getTransaction() {
		
		return wmap;
	}

	@Override
	public boolean addUser(Wallet wallet) {
		
	
		
		try {
			c=CommonCon.getCon();
		PreparedStatement pst=c.prepareStatement("insert into wallet values(?,?,?)");
		
		
		pst.setString(1, wallet.getUsername());
		pst.setString(2, wallet.getPassword());
		pst.setLong(3, wallet.getBalance());
		
		
		
		pst.executeUpdate();
		pst.close();
		
		} 
	
	catch (Exception e2)
	{
		System.out.println(wallet);
	}
	
		return true;
	}

	@Override
	public void createAccount(Customer1 customer) throws MPException {
		
		try {
			
			c=CommonCon.getCon();
			
			
			PreparedStatement pst=c.prepareStatement("insert into customer1 values(?,?,?,?)");
			
			
			pst.setString(1, customer.getCustomerName());
			pst.setString(2, customer.getCustomerPhone());
			pst.setString(3, customer.getCustomerAddress());
			pst.setString(4, customer.getCustomerAdhar());
			
			
			pst.executeUpdate();
			pst.close();
			
			} 
		
		catch (Exception e2)
		{
			System.out.println(customer);
		}
		
	}



	
	

}
