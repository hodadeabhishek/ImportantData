package com.cg.PaymentWallet.dao;



import java.util.Date;
import java.util.Map;

import com.cg.PaymentWallet.Exception.MPException;
import com.cg.PaymentWallet.dto.Customer1;
import com.cg.PaymentWallet.dto.Wallet;




public interface WalletDAO {
	
	int checkBalance();
	long deposit(Wallet wallet, long amount1);
	long withdraw(Wallet wallet, long amount1);
	boolean getAccountdb(String walletId, String passkey) throws MPException;
	long fundTransfer(Wallet wallet, long amount1,String customerAccNo);
	Map<Date, String> getTransaction();
	boolean addUser(Wallet wallet);
	void createAccount(Customer1 customer)throws MPException;
	

}
