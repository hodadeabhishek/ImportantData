import { Component, OnInit } from '@angular/core';
import { GettingshippingdetailsService } from '../gettingshippingdetails.service';
import { Iship } from '../shipping';

@Component({
  selector: 'app-address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.css']
})
export class AddressComponent implements OnInit {
  ship:Iship=new Iship;
  constructor(private service:GettingshippingdetailsService) { 
   
    this.ship=service.ship;
    console.log(this.ship);
  }

  ngOnInit() {
  
    
  }

}
