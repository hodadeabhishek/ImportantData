import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShippingdetailComponent } from './shippingdetail/shippingdetail.component';
import { AddressComponent } from './address/address.component';

const routes: Routes = [

  {path:"",component:ShippingdetailComponent},
  {path:"shiping",component:AddressComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
