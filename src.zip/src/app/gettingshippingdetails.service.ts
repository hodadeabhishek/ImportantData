import { Injectable } from '@angular/core';

import { Iship } from './shipping';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class GettingshippingdetailsService {
 
 shipping:Iship[]=[];
 ship:Iship;
 shipmentId:number;
  
  url="http://localhost:9494/shipment";
  constructor(private http:HttpClient) {
 
    
   }

  getshippingList():any{
    console.log(this.shipmentId)
    return this.http.get<Iship>(this.url);
  
    
  }




}
