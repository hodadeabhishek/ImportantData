

export class Iship{
  
shipmentId:number
addressLine1:String
addressLine2:String
city: String
state: String
pincode: String
   
} 