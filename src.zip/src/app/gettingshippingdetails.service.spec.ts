import { TestBed } from '@angular/core/testing';

import { GettingshippingdetailsService } from './gettingshippingdetails.service';

describe('GettingshippingdetailsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GettingshippingdetailsService = TestBed.get(GettingshippingdetailsService);
    expect(service).toBeTruthy();
  });
});
