import { Component, OnInit } from '@angular/core';
import { GettingshippingdetailsService } from '../gettingshippingdetails.service';
import { Iship } from '../shipping';
import { Router } from '@angular/router';

@Component({
  selector: 'app-shippingdetail',
  templateUrl: './shippingdetail.component.html',
  styleUrls: ['./shippingdetail.component.css']
})
export class ShippingdetailComponent implements OnInit {

 shippingList:Iship[];
 userdeatail:Iship;
 shipmentId:number
addressLine1:String
addressLine2:String
city: String
state: String
pincode: String
details:boolean=false;
  constructor(private service:GettingshippingdetailsService, private router:Router) { }

  ngOnInit() {

    this.service.getshippingList().subscribe(data=>this.shippingList=data);
   
  }
  
  getshippingDetails(){
    let arr=this.shippingList.filter(p=>p.shipmentId==this.shipmentId);
    if(arr.length>0 && !this.details){
      arr.map(p=>this.userdeatail=p);
      this.shipmentId=this.userdeatail.shipmentId;
      this.addressLine1=this.userdeatail.addressLine1;
      this.addressLine2=this.userdeatail.addressLine2;
      this.city=this.userdeatail.city;
      this.state=this.userdeatail.state;
      this.pincode=this.userdeatail.pincode;

      const ship = <Iship>({
        shipmentId:this.shipmentId,
        addressLine1:this.addressLine1,
        addressLine2:this.addressLine2,
        city:this.city,
        state: this.state,
        pincode: this.pincode
        });

this.service.ship=ship;
this.router.navigateByUrl('/shiping');
    }
      else{
      alert("please Enter The Correct Shipment Id ")


    
    }
  

  
    }
    
  }

