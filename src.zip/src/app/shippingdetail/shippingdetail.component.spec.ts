import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShippingdetailComponent } from './shippingdetail.component';

describe('ShippingdetailComponent', () => {
  let component: ShippingdetailComponent;
  let fixture: ComponentFixture<ShippingdetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShippingdetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShippingdetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
