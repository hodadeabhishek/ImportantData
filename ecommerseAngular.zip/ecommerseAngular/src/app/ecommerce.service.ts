import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Iproduct } from './product';
@Injectable({
  providedIn: 'root'
})
export class EcommerceService {

  ProductList:Iproduct;
  url="/assets/db.json";
  constructor(private http:HttpClient) {

    this.getProductList().subscribe(data=>this.ProductList=data);
   }

  getProductList():any{
    return this.http.get<Iproduct>(this.url);
  }
}
