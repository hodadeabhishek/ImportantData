export class Iproduct{
  
    id:String;
    name:String;
    price:number;
    category:String;
   
} 