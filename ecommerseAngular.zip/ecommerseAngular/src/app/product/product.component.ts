import { Component, OnInit } from '@angular/core';
import { Iproduct } from '../product';
import { EcommerceService } from '../ecommerce.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  productarr: Iproduct[];
  constructor(private service:EcommerceService) { }

  ngOnInit() {
    this.service.getProductList().subscribe(data=>this.productarr=data);
    
  }
  delete(product:Iproduct){


    let arr=this.productarr.filter(p=>p.name!=product.name);
    this.productarr=arr;
    console.log(this.productarr);
  }
}
