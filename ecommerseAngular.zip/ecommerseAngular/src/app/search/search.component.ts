import { Component, OnInit } from '@angular/core';
import { EcommerceService } from '../ecommerce.service';
import { Iproduct } from '../product';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  productarr: Iproduct[];

  constructor(private service:EcommerceService) { }

  ngOnInit() {
    this.service.getProductList().subscribe(data=>this.productarr=data);

  }
  search(data:Iproduct){

    let arr= this.productarr.filter(p=>p.name==data.name);
    console.log(arr);
   
    this.productarr=arr;
    
     }
    }
