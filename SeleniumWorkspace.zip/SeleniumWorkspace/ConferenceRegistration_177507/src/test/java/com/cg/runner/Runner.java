package com.cg.runner;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
@RunWith(Cucumber.class)
@CucumberOptions(
		features={"C:\\SeleniumWorkspace\\ConferenceRegistration_177507\\src\\test\\java\\com\\cg\\feature"}
		,glue= {"com.cg.stpdef"}
		//features="com.cg.feature",glue= {"com.cg.stepdef"}
		,plugin = {"pretty", "html:target/abhishek_177507-report"}
		,monochrome=true
		,tags= {"@smoke"}		
//		,dryRun=true
		)
public class Runner
{    

}

 
