package com.cg.capstoremaster.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class ShippingPage {
	
	WebDriver driver;
	@FindBy(how=How.NAME, using="userName")
	@CacheLookup
	private WebElement userName;
	@FindBy(how=How.NAME, using="sub")
	@CacheLookup
	private WebElement request;
	public WebDriver getDriver() {
		return driver;
	}

	public WebElement getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName.sendKeys(userName);
	}
	public void setRequest() {
		this.request.click();
	}
}
