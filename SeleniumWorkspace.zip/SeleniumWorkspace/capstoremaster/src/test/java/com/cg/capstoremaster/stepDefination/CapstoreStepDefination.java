package com.cg.capstoremaster.stepDefination;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.capstoremaster.pom.ShippingPage;


import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CapstoreStepDefination {
	
	private WebDriver driver;
	 WebElement searchBox;
	ShippingPage page;
	 
	 @Given("^user is on shipping detail Page$")
	 public void user_is_on_shipping_detail_Page() throws InterruptedException {
		 System.setProperty("webdriver.chrome.driver", "C://SeleniumJars//chromedriver.exe");
		 driver=new ChromeDriver();
		  driver.get("http://localhost:4200/");
		  driver.manage().window().maximize();
		  page = PageFactory.initElements(driver, ShippingPage.class);
			
		  Thread.sleep(5000);
	 }
		@Then("^check the title of the page$")
		public void check_the_title_of_the_page() throws Throwable {
			
			System.out.println("Title of page: " + driver.getTitle());
			assertEquals("capstore", driver.getTitle());
		}

		@When("^user enter Incorrect shipment id$")
		public void user_enter_Incorrect_shipment_id()  {
			page.setUserName("56");
			page.setRequest();
		   
		}

		@Then("^Display alert box$")
		public void display_alert_box()  {
			Alert alert=driver.switchTo().alert();
			
			String msg=alert.getText();
			if(msg.equals("please Enter The Correct Shipment Id "))
			{
				System.out.println("the msg on text box"+msg);
			}
			else {
				System.out.println("msg on alert box is not correct");
			}
		 
		  alert.accept();
		}
		@When("^user leave field empty$")
		public void user_leave_field_empty()  {
			page.setUserName("");
			page.setRequest();
		  
		}
		@Then("^Display alert box incorrect shippment id$")
		public void display_alert_box_incorrect_shippment_id()  {
			Alert alert=driver.switchTo().alert();
			  alert.accept();
		}


		
		@When("^User enters correct shipping id$")
		public void user_enters_correct_shipping_id(){
			page.setUserName("21");
			
		  
		}

		@When("^click on button$")
		public void click_on_button()  {
			page.setRequest();
		   
		}
}
