package com.cg.stepDefination;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GoogleStepDefination {

	private WebDriver driver;
	 WebElement searchBox;
	 
	 
	 
	 @Given("^user is on Google Home Page$")
	 public void user_is_on_Google_Home_Page() throws InterruptedException  {
		 System.setProperty("webdriver.chrome.driver", "C://SeleniumJars//chromedriver.exe");
		 driver=new ChromeDriver();
		  driver.get("http://www.google.com/");
		  Thread.sleep(5000);
	 }

	 @When("^user finds search box$")
	 public void user_finds_search_box() throws InterruptedException {
		 searchBox = driver.findElement(By.xpath("//input[@name='q']"));
		 Thread.sleep(5000);
	 }

	 @Then("^it enters a search keyword$")
	 public void it_enters_a_search_keyword() throws InterruptedException  {
		 searchBox.sendKeys("narendra modi");
		  searchBox.submit();
		  
		  Thread.sleep(5000);  
	

	 }
	 
	 @Then("^user find link$")
	 public void user_find_link() throws InterruptedException  {
		 searchBox = driver.findElement(By.xpath("//div[contains(text(),'Narendra Modi Oath Ceremony: Karan Johar, Shahid K')]"));
		 Thread.sleep(5000);

	 }

	 @Then("^it click on link$")
	 public void it_click_on_link() throws InterruptedException {
		 searchBox.click();
		 
		  
		  Thread.sleep(5000);  
		 
	   
	 }
	 @Then("^find fb$")
	 public void find_fb() throws InterruptedException  {
		 searchBox = driver.findElement(By.xpath("//body//div[@id='content_2166157']//div[@id='content_2166157']//div[@class='clearfix']//a[1]//img[1]"));
		 Thread.sleep(5000);
	   
	 }
	 @Then("^it click on fb$")
	 public void it_click_on_fb() throws InterruptedException  {
		 searchBox.click();
		 
		  
		  Thread.sleep(5000);  
		  driver.quit();
	   
	 }


	 
	 
	 
	 
	 
	 
	 
	 

}
