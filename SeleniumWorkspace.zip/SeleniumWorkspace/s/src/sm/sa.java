package sm;

import java.util.TreeSet;

public class sa {

	public static class lamdademo {

		public static void main(String[] args) {

			TreeSet<Integer> treeset = new TreeSet<Integer>((o1,o2)->(o1>o2)?-1:(o1<o2)?1:0);
			treeset.add(850);
			treeset.add(235);
			treeset.add(1080);
			treeset.add(15);
			treeset.add(5);
			System.out.println(treeset);
		}

	}
}
