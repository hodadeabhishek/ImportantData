package com.cg.bdd;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class PopupWindow {

	public static void main(String[] args) throws InterruptedException {
		 System.setProperty("webdriver.chrome.driver", "C://SeleniumJars//chromedriver.exe");
		  WebDriver driver = new ChromeDriver();
		  
		  driver.get("file:///C:/Testing/Lesson%205-HTML%20Pages/PopupWin.html");
		  
		 
		  
		
		  driver.findElement(By.name("Open")).click();
 
		  String parentWindow = driver.getWindowHandle().toString();
		  driver.switchTo().window("PopupWindow");
			driver.close();
			
			Thread.sleep(5000);
			driver.switchTo().window(parentWindow);
			
			driver.close();

	}
}
