package com.cg.bdd;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WikipediaAutomation {
	public static void main(String[] args) throws InterruptedException {
		
		 System.setProperty("webdriver.chrome.driver", "C://SeleniumJars//chromedriver.exe");
		  WebDriver driver = new ChromeDriver();
		  driver.get("http://www.google.com/xhtml");
		  Thread.sleep(5000); 
		  WebElement searchBox = driver.findElement(By.xpath("//input[@id='searchInput']"));
		  searchBox.sendKeys("https://en.wikipedia.org/wiki/Main_Page");
		  searchBox.submit();
		  Thread.sleep(5000);  
		  driver.quit();

	}

}
