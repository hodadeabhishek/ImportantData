package com.cg.bdd;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertBox {
	
	public static void main(String[] args) {
		
		 System.setProperty("webdriver.chrome.driver", "C://SeleniumJars//chromedriver.exe");
		  WebDriver driver = new ChromeDriver();
		  driver.get("file:///C:/Testing/Lesson%205-HTML%20Pages/AlertExample.html");
		  
		  driver.findElement(By.name("btnAlert")).click();
		  
		  String alertmsg;
		  
		  alertmsg=driver.switchTo().alert().getText();
		  
		  driver.switchTo().alert().accept();
		  
		  System.out.println(alertmsg);
		
	}

}
