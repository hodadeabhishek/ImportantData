package com.cg.bdd;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="C:\\SeleniumWorkspace\\githubLogin\\feature\\login.feature",glue="com.cg.stepDefination")
public class MyRunner {

	
}
