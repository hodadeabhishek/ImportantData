package com.cg.stepDefinatination;

public class GithubLoginStepDefination {

}
