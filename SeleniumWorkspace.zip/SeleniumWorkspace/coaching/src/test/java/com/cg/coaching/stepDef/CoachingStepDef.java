package com.cg.coaching.stepDef;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.coaching.pom.CoachingPage;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class CoachingStepDef {

	WebDriver driver;
	CoachingPage page;

	@Given("^user is on coaching enquiry form$")
	public void user_is_on_coaching_enquiry_form() throws Throwable {

		 System.setProperty("webdriver.chrome.driver", "C://SeleniumJars//chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(
				"C:\\SeleniumWorkspace\\coaching\\src\\test\\java\\com\\cg\\coaching\\html\\Coaching_Class_Enquiry.html");
		driver.manage().window().maximize();
		page = PageFactory.initElements(driver, CoachingPage.class);
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		
		System.out.println("Title of page: " + driver.getTitle());
		assertEquals("Coaching_Class_Enquiry", driver.getTitle());
	}

	@Then("^check if text is present$")
	public void check_if_text_is_present() throws Throwable {
		System.out.println("Text on the page: " + page.getText());
		assertEquals("Tution Enquiry Details Form",page.getText());
	}

	@Given("^fill form data except first name$")
	public void fill_form_data_except_first_name() throws Throwable {
	
		page.setFname("");Thread.sleep(500);
		page.setLname("Raipure");Thread.sleep(500);
		page.setEmail("anujaraipure@gmail.com");Thread.sleep(500);
		page.setMobile("8087864923");Thread.sleep(500);
		page.setCity("Pune");Thread.sleep(500);
		page.setLearningMode("Class Room Training");Thread.sleep(500);
		page.setTuitionType("Spoken English");Thread.sleep(500);
		page.setEnquiry("I want to know if crash course is available for spoken english.");
	}

	@Given("^click on submit$")
	public void click_on_submit() throws Throwable {
		Thread.sleep(3000);
		page.setRequest();
	}

	@Then("^switch to alert and accept it$")
	public void switch_to_alert_and_accept_it() throws Throwable {
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	}

	@Given("^fill form data except last name$")
	public void fill_form_data_except_last_name() throws Throwable {
		page.setFname("Anuja");Thread.sleep(500);
		page.setLname("");Thread.sleep(500);
		page.setEmail("anujaraipure@gmail.com");Thread.sleep(500);
		page.setMobile("8087864923");Thread.sleep(500);
		page.setCity("Pune");Thread.sleep(500);
		page.setLearningMode("Class Room Training");Thread.sleep(500);
		page.setTuitionType("Spoken English");Thread.sleep(500);
		page.setEnquiry("I want to know if crash course is available for spoken english.");Thread.sleep(500);
	}

	@Given("^fill form data except email$")
	public void fill_form_data_except_email() throws Throwable {
		page.setFname("Anuja");Thread.sleep(500);
		page.setLname("Raipure");Thread.sleep(500);
		page.setEmail("");Thread.sleep(500);
		page.setMobile("8087864923");Thread.sleep(500);
		page.setCity("Pune");Thread.sleep(500);
		page.setLearningMode("Class Room Training");Thread.sleep(500);
		page.setTuitionType("Spoken English");Thread.sleep(500);
		page.setEnquiry("I want to know if crash course is available for spoken english.");
	}

	@Given("^fill form data except mobile$")
	public void fill_form_data_except_mobile() throws Throwable {
		page.setFname("Anuja");Thread.sleep(500);
		page.setLname("Raipure");Thread.sleep(500);
		page.setEmail("anujaraipure@gmail.com");Thread.sleep(500);
		page.setMobile("");Thread.sleep(500);
		page.setCity("Pune");Thread.sleep(500);
		page.setLearningMode("Class Room Training");Thread.sleep(500);
		page.setTuitionType("Spoken English");Thread.sleep(500);
		page.setEnquiry("I want to know if crash course is available for spoken english.");Thread.sleep(500);
	}

	@Given("^fill form data except tuition type$")
	public void fill_form_data_except_tuition_type() throws Throwable {
		page.setFname("Anuja");Thread.sleep(500);
		page.setLname("Raipure");Thread.sleep(500);
		page.setEmail("anujaraipure@gmail.com");Thread.sleep(500);
		page.setMobile("8087864923");Thread.sleep(500);
		page.setCity("Pune");Thread.sleep(500);
		page.setLearningMode("Class Room Training");Thread.sleep(500);
		//page.setTuitionType("");
		page.setEnquiry("I want to know if crash course is available for spoken english.");
	}

	@Given("^fill form data except city$")
	public void fill_form_data_except_city() throws Throwable {
		page.setFname("Anuja");Thread.sleep(500);
		page.setLname("Raipure");Thread.sleep(500);
		page.setEmail("anujaraipure@gmail.com");Thread.sleep(500);
		page.setMobile("8087864923");Thread.sleep(500);
		//page.setCity("");
		page.setLearningMode("Class Room Training");Thread.sleep(500);
		page.setTuitionType("Spoken English");Thread.sleep(500);
		page.setEnquiry("I want to know if crash course is available for spoken english.");
	}

	@Given("^fill form data except mode of learning$")
	public void fill_form_data_except_mode_of_learning() throws Throwable {
		page.setFname("Anuja");Thread.sleep(500);
		page.setLname("Raipure");Thread.sleep(500);
		page.setEmail("anujaraipure@gmail.com");Thread.sleep(500);
		page.setMobile("8087864923");Thread.sleep(500);
		page.setCity("Pune");Thread.sleep(500);
		//page.setLearningMode("");
		page.setTuitionType("Spoken English");Thread.sleep(500);
		page.setEnquiry("I want to know if crash course is available for spoken english.");
	}

	@Given("^fill form data except enquiry details$")
	public void fill_form_data_except_enquiry_details() throws Throwable {
		page.setFname("Anuja");Thread.sleep(500);
		page.setLname("Raipure");Thread.sleep(500);
		page.setEmail("anujaraipure@gmail.com");Thread.sleep(500);
		page.setMobile("8087864923");Thread.sleep(500);
		page.setCity("Pune");Thread.sleep(500);
		page.setLearningMode("Class Room Training");Thread.sleep(500);
		page.setTuitionType("Spoken English");Thread.sleep(500);
		page.setEnquiry("");
	}
	
	@Given("^fill form data$")
	public void fill_form_data() throws Throwable{
		page.setFname("Anuja");Thread.sleep(500);
		page.setLname("Raipure");Thread.sleep(500);
		page.setEmail("anujaraipure@gmail.com");Thread.sleep(500);
		page.setMobile("8087864923");Thread.sleep(500);
		page.setCity("Pune");Thread.sleep(500);
		page.setLearningMode("Class Room Training");Thread.sleep(500);
		page.setTuitionType("Spoken English");Thread.sleep(500);
		page.setEnquiry("I want to know if crash course is available for spoken english.");
		
	}

	@After
	public void closeDriver() throws InterruptedException {
		Thread.sleep(1000);
		driver.close();
	}
}
